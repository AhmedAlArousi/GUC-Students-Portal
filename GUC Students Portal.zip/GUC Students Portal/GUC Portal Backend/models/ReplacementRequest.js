const mongoose= require('mongoose');
const replacementRequest = mongoose.Schema({
    senderId:{type:String,required:true},
    receiverId:{type:String,required:true},
    department:{type:String,required:true},
    statusInst:{type:String,required:true},
    statusHod:{type:String,required:true},//from boolean to string
    SeenSender:{type:Boolean,required:true},//from string to boolean
    SeenReceiver:{type:Boolean,required:true},
    reason:{type:String},
    Date:{type:Date,required:true},
    slot:{type:String}
});
module.exports=mongoose.model('ReplacementRequest', replacementRequest);