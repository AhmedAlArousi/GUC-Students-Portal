const mongoose= require('mongoose');
const faculty = mongoose.Schema({
    name:{type:String,required:true,unique:true},
    code:{type:String,required:true,unique:true}
});
module.exports=mongoose.model('Faculty',faculty);