const mongoose= require('mongoose');
// date format is y-m-dTh:m:sZ
const course = mongoose.Schema({
    name:{type:String,required:true,unique:true},
    coordinatorId:{type:String,required:true},
    code:{type:String,required:true,unique:true},
    mainDepartment:{type:String,required:true},
    slots:[{day:{type:String,required:true},slot:{type:String,required:true},location:{type:String},academic:{type:String}}],//we will see whether
    //we use location by name or id 
    coverage:{type:Number,required:true}
});
module.exports=mongoose.model('Course',course);