const mongoose= require('mongoose');
const department = mongoose.Schema({
    name:{type:String,required:true,unique:true},
    code:{type:String,required:true,unique:true},//shorthand for department
    facultyId:{type:String,required:true},
    headOfDepartmentId:{type:String,required:true},
    coursesIds:[{courseId:{type:String,required:true}}]
});
module.exports=mongoose.model('Department',department);