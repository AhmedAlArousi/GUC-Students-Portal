const mongoose= require('mongoose');
// [2.5,2.5,2.5,2.5,2.5,2.5,2.5,2.5,2.5,2.5,2.5,2.5]
const staff = mongoose.Schema({
     id:{type:String,required:true,unique:true},
     email:{type:String,required:true,unique:true},
     password:{type:String,required:true},
     name:{type:String,required:true},
     salary:{type:Number,required:true},
     gender:{type:String,enum:['male','female'],required:true},
     officeLocation:{type:String,required:true},
     role:{type:String,enum:['HR','instructor','TA','coordinator','HOD'],required:true},
    // annualLeaves:{ type: [Number], required: true },
     signInLogs:[{timeStamp:{type:Date,required:true},type:{type:String,enum:['in','out'],required:true}}],
     dayOff:{type:String,required:true},
     coursesIds:[{courseId:{type:String,required:true}}],
     schedule:[{day:{type:String,required:true},slot:{type:String,required:true},course:{type:String,required:true},location:{type:String,required:true}}],//we will see whether
     //we use location by name or id 
     department:{type:String,required:true}
});
module.exports=mongoose.model('Staff', staff);