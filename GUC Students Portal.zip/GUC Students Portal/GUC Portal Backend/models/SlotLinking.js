const mongoose= require('mongoose');
const slotLinking = mongoose.Schema({
    senderId:{type:String,required:true},
    courseId:{type:String,required:true},//from number to string
    status:{type:String,required:true},
    slot:{type:String,required:true},
    day:{type:String,required:true},
    location:{type:String,required:true},
    SeenSender:{type:Boolean,required:true},
    SeenReceiver:{type:Boolean,required:true}
});
module.exports=mongoose.model('SlotLinking',  slotLinking);