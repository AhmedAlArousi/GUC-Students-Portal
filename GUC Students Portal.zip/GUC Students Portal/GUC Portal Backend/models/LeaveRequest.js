const mongoose= require('mongoose');
const leaveRequest = mongoose.Schema({
    senderId:{type:String,required:true},
    typeOfLeave:{type:String,required:true},
    // status should be enum accepted,pending,rejected
    status:{type:String,required:true},
    startDate:{type:Date,required:true},
    periodOfLeave:{type:Number,required:true},
    document:{type:String},
    department:{type:String},
    reason:{type:String},
    SeenSender:{type:Boolean,required:true},
    SeenReceiver:{type:Boolean,required:true},
    compensatingDay:{type:Date}
});
module.exports=mongoose.model('LeaveRequest', leaveRequest);