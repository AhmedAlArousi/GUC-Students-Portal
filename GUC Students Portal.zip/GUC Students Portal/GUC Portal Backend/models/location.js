const mongoose= require('mongoose');
const location = mongoose.Schema({
    name:{type:String,required:true,unique:true},
    type:{type:String,required:true},
    maxCapacity:{type:Number,required:true},
    curCapacity:{type:Number}
});
module.exports=mongoose.model('Location',location);