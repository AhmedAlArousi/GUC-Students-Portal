const mongoose= require('mongoose');

const blackListedTokens = mongoose.Schema({
    jwt : {type : String , required : true}
})

module.exports=mongoose.model('TokenBlackList', blackListedTokens);