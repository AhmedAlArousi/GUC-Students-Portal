const mongoose= require('mongoose');
const changeDayOff = mongoose.Schema({
    senderId:{type:String,required:true},
    newday:{type:String,required:true}, 
    // status should be enum accepted,pending,rejected
    status:{type:String,required:true},
    reasonOfChange:{type:String},
    comment:{type:String},
    department:{type:String,required:true},  
    SeenSender:{type:Boolean,required:true},
    SeenReceiver:{type:Boolean,required:true}
});
module.exports=mongoose.model('ChangeDayOff', changeDayOff);