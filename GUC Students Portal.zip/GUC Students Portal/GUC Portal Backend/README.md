# **GUC Portal**


## **File to run**
index.js in root (use npm start)

## **UML link**
https://drive.google.com/file/d/1V1l3hMCBwKQ3BcTgA-Fakt9LZobrTwDy/view?usp=sharing

## **Port number**
3000 

## **General Notes**
You need to add ur db url(variable name :URL_MONGO) and token secret for security(variable name:tokenSecret) in .env file 
To seed db use route /seed(adds an hr member,a hod,a location,a department and a faculty )
To test mising days/hr or attendance , use the route of hr that adds  a missing sign in/out record for a certain staff member
except themselves
#### **Functionality**: Seed db  
**Route**: /seed  
**Request type**: POST  
**Request body**: Empty  
## **Routes**
*Note*: All routes with no responses have a displayed msg stating whether action is done successfully or there exists an error
### **Staff**

#### **Functionality**: Log in  
**Route**: /login  
**Request type**: POST  
**Request body**: {"email" : "leader@guc.edu.eg","password" : "123456","newPassword" : "Password123"}
**Reponse body**: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFobWVkQGFobWVkLmNvbSIsImlkIjoiYWMtMTIiLCJuYW1lIjoiYWhtZWQiLCJpYXQiOjE2MDg4OTI3NTF9.h_a_X68yPgIsDIDufNOtfd5t1Hfw9d3aHx4g3b1gzLY
**Notes**: if its the first time to login in you have to enter newPassword ,, the response is the token
***  

#### **Functionality**: Log out  
**Route**: /staff/logout  
**Request type**: GET  
**Request body**: Empty  
***

#### **Functionality**: View profile  
**Route**: /staff/viewProfile  
**Request type**: GET  
**Request body**: Empty
**Response body** : {
    "ID": "ac-12",
    "Email": "ahmed@guc.com",
    "Name": "ahmed",
    "Password": "$2b$10$HPzkqE.LGVCdIoagGynqbuux8WBiINeWewzIewNUdfpSmbvHMMrta",
    "Gender": "male",
    "Role": "instructor",
    "Salary": 10000000000,
    "Office location": "c4.101",
    "Schedule": [],
    "My courses": [],
    "Annual Leaves": [
        0
    ],
    "Sign-in logs": [
        {
            "Date": "Wed, 18 Nov 2020 13:57:05 GMT",
            "Type": "in"
        },
        {
            "Date": "Wed, 18 Nov 2020 13:58:05 GMT",
            "Type": "out"
        },
        {
            "Date": "Thu, 19 Nov 2020 13:40:05 GMT",
            "Type": "in"
        },
        {
            "Date": "Thu, 19 Nov 2020 13:41:05 GMT",
            "Type": "out"
        },
    ],
    "Off day": "monday",
    "Department": "met"
}  
***

#### **Functionality**: Update profile  
**Route**: /staff/updateProfile  
**Request type**: PUT  
**Request body**: {"email" : "mail@guc.com"} 
**Response body** : "Your email has changed to : mail@guc.com" 
***

#### **Functionality**: Reset password 
**Route**: /staff/resetPassword  
**Request type**: PUT  
**Request body**: {"oldPassword" : "oldPassword" , "newPassword" : "Password123"}
**Response body**: "Your password has changed successfully"  
***  
 
#### **Functionality**: Sign in 
**Route**: /staff/signIn  
**Request type**: POST  
**Request body**: Empty
**Notes**: Cannot sign in on Friday
***  

#### **Functionality**: Sign out 
**Route**: /staff/signOut  
**Request type**: POST  
**Request body**: Empty 
**Notes**: Cannot sign out on Friday 
***

#### **Functionality**: View attendance 
**Route**: /staff/viewAttendance  
**Request type**: GET  
**Request body**: Empty  
**Response body**:
[   
    {
        "Date": "Wed, 18 Nov 2020 13:57:05 GMT",
        "Type": "in"
    },
    {
        "Date": "Wed, 18 Nov 2020 13:58:05 GMT",
        "Type": "out"
    },
    {
        "Date": "Thu, 19 Nov 2020 13:40:05 GMT",
        "Type": "in"
    },
    {
        "Date": "Thu, 19 Nov 2020 13:41:05 GMT",
        "Type": "out"
    }
]  
***

#### **Functionality**: View attendance by month 
**Route**: /staff/viewAttendanceBymonth  
**Request type**: GET  
**Request body**: {"month" : "December"}
**Response body**:
[   
    {
        "Date": "Sat, 12 Dec 2020 10:00:00 GMT",
        "Type": "in"
    },
    {
        "Date": "Sat, 12 Dec 2020 16:00:00 GMT",
        "Type": "out"
    },
     {
        "Date": "Mon, 14 Dec 2020 10:00:00 GMT",
        "Type": "in"
    },
    {
        "Date": "Mon, 14 Dec 2020 13:00:00 GMT",
        "Type": "out"
    },
]    
***

#### **Functionality**: View missing days  
**Route**: /staff/viewMissingDays  
**Request type**: GET  
**Request body**: Empty
**Response body**: [
    "2020-12-13T10:00:00.000Z",
    "2020-12-15T10:00:00.000Z",
    "2020-12-16T10:00:00.000Z",
    "2020-12-17T10:00:00.000Z",
    "2020-12-19T10:00:00.000Z",
    "2020-12-20T10:00:00.000Z",
    "2020-12-22T10:00:00.000Z",
    "2020-12-23T10:00:00.000Z",
    "2020-12-24T10:00:00.000Z"
]
**Notes**: missing days are the days missed in the same month the route is used  
***

#### **Functionality**: View missing hours  
**Route**: /staff/viewMissingHours  
**Request type**: GET  
**Request body**: Empty
**Response body**: {
    "Missinghours": 19.17,
    "ExtraHours": 3.1
}  
**Notes**: missing days are the days missed in the same month the route is used  
***

### **HR**
#### **Functionality**: add a new location  
**Route**: /hr/location  
**Request type**: POST  
**Request body**: {"name" : "C3.320", "type": "office", "curCapacity": 5, "maxCapacity":20 }  
**Notes**: curCapacity shall be omitted upon adding lab/tutorial/hall  
***
#### **Functionality**: delete a location  
**Route**: /hr/location  
**Request type**: DELETE  
**Request body**: {"name" : "C3.320"}   
***
#### **Functionality**: update a location  
**Route**: /hr/location  
**Request type**: PUT  
**Request body**: {"key":"C3.320", "name" : "C3.315", "maxCapacity":20 }  
**Notes**: key is the name of required room to update, the rest can be any combination of fields to be updated, cant change type of room
***
#### **Functionality**: add a new faculty  
**Route**: /hr/faculty  
**Request type**: POST  
**Request body**: {"name":"Engineering","code":"ENG" }  
***
#### **Functionality**: delete a faculty  
**Route**: /hr/faculty  
**Request type**: DELETE  
**Request body**: {"code" : "ENG"}  
***
#### **Functionality**: update a faculty  
**Route**: /hr/faculty  
**Request type**: PUT  
**Request body**: {"key":"ENG", "name" : "Manufacturing","code":"MNF"}  
**Notes**: key is the code of required faculty to update, the rest can be any combination of fields to be updated  
***
#### **Functionality**: add a new department  
**Route**: /hr/department  
**Request type**: POST  
**Request body**: { "code": "MET","name":"Media Eng and Tech","facCode":"ENG" }  
 the staff id chosen must belong to an instructor,and hr cannot add any courses  (hr assigns hod in PUT),hod assigned in put  
***
#### **Functionality**: delete a department  
**Route**: /hr/department  
**Request type**: DELETE  
**Request body**: {"code" : "IET"}  
***
#### **Functionality**: update a department  
**Route**: /hr/department  
**Request type**: PUT  
**Request body**: {"key":"MET", "code": "MET","name":"Media Eng and Tech","facCode":"ENG" ,"headOfDepartmentId":"ac-1"}  
**Notes**: hod added here  
***
#### **Functionality**: add a new course  
**Route**: /hr/course  
**Request type**: POST  
**Request body**: {"name":"theory","code":"CSEN502","dep":"MET"}  
**Notes**: if the course is initially created it's main department will be the first added one,hr cannot add anything else  
***
#### **Functionality**: delete a course under department  
**Route**: /hr/course  
**Request type**: DELETE  
**Request body**: { "codeCourse":"CSEN502","codeDepartment":"MET"}  
**Notes**: we specity the department as a couse can be taught in several departments  
***
#### **Functionality**: update a course  
**Route**: /hr/course  
**Request type**: PUT  
**Request body**: {"key":"CSEN502","name":"computations","code":"CSEN507"}  
**Notes**: hr cannot change anything else  
***
#### **Functionality**: add a new staff member  
**Route**: /hr/member  
**Request type**: POST  
**Request body**: {"email" : "foo@guc.edu.eg","name" : "timo","salary" : 10000000000,"gender" : "male","officeLocation" : "C3.320","role": "TA","dayOff" :"Tuesday","department" :  "MET"}  
**Response body**:
{  
    "_id": "5fde5dff083dca5cf0b68fab",  
    "id": "ac-5",  
    "email": "foo@guc.edu.eg",  
    "name": "timo",  
    "password": "123456",  
    "salary": 10000000000,  
    "gender": "male",  
    "officeLocation": "5fde57f8a49666263886572b",  
    "role": "TA",  
    "annualLeaves": 0,  
    "signInLogs": [],  
    "dayOff": "Tuesday",  
    "coursesIds": [],  
    "schedule": [],  
    "department": "5fde5de7083dca5cf0b68faa",  
    "__v": 0  
}  
**Notes**:upon adding hr member,he cannot add dayoff other than saturday(so put Saturday in dayoff),check scheme for writing days as enum states
also check scheme to write role as enum states,(PASSWORD IS NOT HASHED ONLY UPON ADDING NEW MEMBER,WHEN STAFF MEMBER CHANGES IT ,IT BECOMES HASHED)
department shown is the id of department in the department model and same for officeloc , the id of the staff appears incrementally(not necessarily ac-5)  
***
#### **Functionality**: delete a staff member  
**Route**: /hr/member  
**Request type**: DELETE  
**Request body**: {"id":"ac-5"}  
***
#### **Functionality**: update a staff member  
**Route**: /hr/member  
**Request type**: PUT  
**Request body**: {"id":"ac-5","name" : "timo","officeLocation" : "C3.315","role": "HOD","dayOff" :"Tuesday","department" :  "MET"}  
**Notes**:use any combination to update staff member of id ac-5  (can only update role from instructor to HOD) 
also dayoff must match an existing change dayoff request &cannot update the email  
***
#### **Functionality**: add a missing sign in/out record  
**Route**: /hr/addSignRec  
**Request type**: POST  
**Request body**: {"id":"ac-1","timeStamp":"2020-12-30T07:06:44Z","type":"in"}  
**Notes**: type can be in or out , date must be in that format,(hr cannot add record for themselves)  
***
#### **Functionality**: View any staff member attendance record.  
**Route**: /hr/viewAttendanceStaff  
**Request type**: GET  
**Request body**: {"id":"ac-1"}  
**Reponse body**: [  
    {  
        "_id": "5fdcde9cda98fa54d4bcf608",  
        "timeStamp": "2020-12-31T16:06:44.000Z",  
        "type": "out"  
    },  
    {  
        "_id": "5fdcde8bda98fa54d4bcf602",  
        "timeStamp": "2020-12-31T12:06:44.000Z",  
        "type": "in"  
    },  
    {  
        "_id": "5fdcde82da98fa54d4bcf5fd",  
        "timeStamp": "2020-12-31T10:06:44.000Z",  
        "type": "out"  
    },  
    {  
        "_id": "5fdcde77da98fa54d4bcf5f9",  
        "timeStamp": "2020-12-31T08:06:44.000Z",  
        "type": "in"  
    }  
]  
**Notes**: shows all records from latest to oldest  
***
#### **Functionality**: show missing days of a staff member   
**Route**: /hr/showMissingDaysHr  
**Request type**: GET  
**Request body**: {"id":"ac-1"}  
**Response body**:{"days": 22,"dates": ["2020-11-11T10:00:00.000Z","2020-11-12T10:00:00.000Z","2020-11-14T10:00:00.000Z","2020-11-15T10:00:00.000Z","2020-11-16T10:00:00.000Z","2020-11-18T10:00:00.000Z","2020-11-19T10:00:00.000Z","2020-11-21T10:00:00.000Z","2020-11-22T10:00:00.000Z","2020-11-23T10:00:00.000Z","2020-11-25T10:00:00.000Z","2020-11-26T10:00:00.000Z","2020-11-28T10:00:00.000Z","2020-11-29T10:00:00.000Z","2020-11-30T10:00:00.000Z","2020-12-02T10:00:00.000Z","2020-12-03T10:00:00.000Z","2020-12-05T10:00:00.000Z","2020-12-06T10:00:00.000Z","2020-12-07T10:00:00.000Z","2020-12-09T10:00:00.000Z","2020-12-10T10:00:00.000Z"]}
**Notes**: shows missing days of a staff member in previous month
***
#### **Functionality**: show missing and extra hours of a staff member   
**Route**: /hr/showMissingHoursHr  
**Request type**: GET  
**Request body**: {"id":"ac-1"}  
**Response body**:{"missingHours": 8.00,"extraHours": 15.61}
**Notes**: shows missing hours of a staff member from beginning of current month until the day before performing the request
***
#### **Functionality**: update a salary of a staff member  
**Route**: /hr/member  
**Request type**: PUT  
**Request body**: {"id":"ac-5", "salary":500}  
***

### **Academics**  
#### **Functionality** : Cancel a still pending request or a request whose day is yet to come   
**Route**: /ac/cancelRequest       
**Request type**: DELETE      
**Request body**: {"reqId":"5fe02c9f7125b8fae5da3a73","typeOfRequest":"replacementRequests"}   
**Notes**:the reqId is the string of mongo _id of the request, this will be handled in the front end     
***

#### **Functionality** : View the status of all submitted requests. They can also view only the accepted requests,only the pending requests or only the rejected requests  view={all,accepted,rejected,pending}    
**Route**: /ac/viewStatusOfRequests       
**Request type**: GET      
**Request body**: {"view":"accepted"}   
**Response body**:{
    "replacementsInst": [
        {
            "_id": "5fdf46ba606f1c5fb94d7c13",
            "senderId": "ac-2",
            "receiverId": "ac-1",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "accepted",
            "statusHod": "accepted",
            "SeenSender": true,
            "SeenReceiver": true,
            "Date": "2020-12-20T09:00:00.000Z",
            "__v": 0
        },
        {
            "_id": "5fe02a59ca34c16348cdc496",
            "senderId": "ac-2",
            "receiverId": "ac-4",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "pending",
            "statusHod": "accepted",
            "SeenSender": true,
            "SeenReceiver": true,
            "Date": "2021-01-03T22:00:00.000Z",
            "__v": 0
        },
        {
            "_id": "5fe02a60ca34c16348cdc497",
            "senderId": "ac-2",
            "receiverId": "ac-1",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "pending",
            "statusHod": "accepted",
            "SeenSender": true,
            "SeenReceiver": true,
            "Date": "2021-01-02T22:00:00.000Z",
            "__v": 0
        },
        {
            "_id": "5fe0b2375b9c08d4605b36f9",
            "senderId": "ac-1",
            "receiverId": "ac-2",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "accepted",
            "statusHod": "accepted",
            "SeenSender": true,
            "SeenReceiver": true,
            "reason": "3ayez araya7",
            "Date": "2020-12-21T00:00:00.000Z",
            "slot": "2nd",
            "__v": 0
        }
    ],
    "leavesSent": [
        {
            "_id": "5fe5a6a107761c09da1e6f98",
            "senderId": "ac-2",
            "typeOfLeave": "Accidental",
            "status": "accepted",
            "startDate": "2020-12-22T09:00:00.000Z",
            "periodOfLeave": 1,
            "document": "a document",
            "department": "5fdf2ab3a70f7a94646830fb",
            "reason": "3ayez araya7",
            "SeenSender": false,
            "SeenReceiver": false,
            "__v": 0
        }
    ],
    "changeDayOffSent": [],
    "slotLinkingSent": []
}     
***  

#### **Functionality** : Notifed whenever their requests are accepted or rejected      
**Route**: /ac/notification     
**Request type**: GET    
**Request body**: {} 
**Response body**:{
    "replacementsInst": [],
    "replacementsHod": [
        {
            "_id": "5fe02a59ca34c16348cdc496",
            "senderId": "ac-2",
            "receiverId": "ac-4",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "pending",
            "statusHod": "accepted",
            "SeenSender": false,
            "SeenReceiver": true,
            "Date": "2021-01-03T22:00:00.000Z",
            "__v": 0
        }
    ],
    "leaveReq": [],
    "changeDayOff": [],
    "slotInking": [
        {
            "_id": "5fdf60ce8b8a00118a424481",
            "senderId": "ac-2",
            "courseId": "5fdf2f4ca70f7a94646830ff",
            "status": "accepted",
            "slot": "4th",
            "day": "monday",
            "SeenSender": false,
            "SeenReceiver": false,
            "__v": 0
        }
    ]
}     
***

#### **Functionality** : Submit any type of \leave" request (automatically sent to HOD).Compensation leave must have a reason. For any other leave, academic members can optionally write a brief reason behind it. Accepted leaves are not calculated as missing hours or missing days    
**Route**: /ac/leaveRequest       
**Request type**: POST   
**Request body**: {"typeOfLeave":"Compensation","startDate":"2021-2-23","periodOfLeave":1,"document":"a link for the document","reason":"3ayez araya7","compensatingDay":"2021-2-25"}    
**Notes**:for Compensation it needs compensatingDay , Sick and Maternity needs a document    
***  

#### **Functionality** : Change their day off by sending a change day off request (automatically sent to HOD),and optionally leave a reason     
**Route**: /ac/changeDayOff      
**Request type**: POST     
**Request body**: {"newday":"Monday","reasonOfChange":"mesh 3agebny","comment":"engezo"}     
***

#### **Functionality** : Send a slot linking request (automatically sent to course coordinator). A slot linking request is a request done by the academic member to indicate their desire to teach a slot       

**Route**: /ac/slotLinkingRequest         
**Request type**: POST        
**Request body**: {"courseCode":"CSEN704","slot":"2nd","day":"Sunday","location":"C5.205"}        

***

#### **Functionality** : Academic can accept or reject a replacement request       
**Route**: /ac/replacementRequestAccReg           
**Request type**: PUT          
**Request body**: {"senderId":"ac-1","Date":"2020-12-21","statusInst":"rejected"}          
***  

#### **Functionality** : Academic send replacement request to HOD         
**Route**: /ac/replacementRequest          
**Request type**: PUT          
**Request body**: {"receiverId":"ac-2","Date":"2021-1-3"}        
***

#### **Functionality** : Academic view his sent replacement requests and the ones he/she received         
**Route**: /ac/replacementRequest          
**Request type**: GET          
**Request body**: {}  
**Response body**:{
    "replacementsSentReceived": [
        {
            "_id": "5fdf46ba606f1c5fb94d7c13",
            "senderId": "ac-2",
            "receiverId": "ac-1",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "accepted",
            "statusHod": "accepted",
            "SeenSender": true,
            "SeenReceiver": true,
            "Date": "2020-12-20T09:00:00.000Z",
            "__v": 0
        },
        {
            "_id": "5fe02a59ca34c16348cdc496",
            "senderId": "ac-2",
            "receiverId": "ac-4",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "pending",
            "statusHod": "pending",
            "SeenSender": false,
            "SeenReceiver": false,
            "Date": "2021-01-03T22:00:00.000Z",
            "__v": 0
        },
        {
            "_id": "5fe0b2375b9c08d4605b36f9",
            "senderId": "ac-1",
            "receiverId": "ac-2",
            "department": "5fdf2ab3a70f7a94646830fb",
            "statusInst": "rejected",
            "statusHod": "accepted",
            "SeenSender": false,
            "SeenReceiver": true,
            "reason": "3ayez araya7",
            "Date": "2020-12-21T00:00:00.000Z",
            "slot": "2nd",
            "__v": 0
        }
    ]
}        
***

#### **Functionality** : Academic send replacement request to colleague          
**Route**: /ac/replacementRequest            
**Request type**: POST            
**Request body**: {"receiverId":"ac-2","Date":"2021-1-3","reason":"3ayez araya7","slot":"2nd"}         
***

#### **Functionality** : Academic view his/her personal schedule          
**Route**: /ac/schedule               
**Request type**: GET              
**Request body**: {}   

**Response body**:[
    {
        "day": "Tuesday",
        "slot": "4th",
        "course": "5fdf2ee5a70f7a94646830fc",
        "location": "5fdf1c3613f1b829b2df7266"
    },
    {
        "_id": "5fe63abdded04d4353dd06fa",
        "day": "Monday",
        "slot": "2nd",
        "course": "5fdf2ee5a70f7a94646830fc",
        "location": "5fdf1c3613f1b829b2df7266"
    }
]          
***

### **TA**
Same functionalities of all academics
***
### **HOD**
#### **Functionality** : assign a course instructor for a course in the HOD  department  
**Route**: /hod/courseInstructor   
**Request type**: POST  
**Request body**: {"id":"ac-5","courseName":"theory"}  
***

#### **Functionality** : delete a course from a course instructor from the HOD department   
**Route**: /hod/courseInstructor     
**Request type**: DELETE    
**Request body**: {"id":"ac-5","courseName":"theory"}  

***

#### **Functionality** : update a course from a course instructor to another course instructor from the HOD department   
**Route**: /hod/courseInstructor     
**Request type**: PUT      
**Request body**: {"idOld":"ac-5","idNew":"ac-2","courseName":"theory"}  

***

#### **Functionality** : view all the staff in the HOD department   
**Route**: /hod/viewStaffinDepartment      
**Request type**: GET      
**Response body**: [{"id":"ac-5", "email" : "foo@guc.edu.eg","name" : "timo","officeLocation" : "C3.315","role": "HOD","dayOff" :"Tuesday","department" :  "MET"},{"id":"ac-6", "email" : "foo1@guc.edu.eg","name" : "mahdy","officeLocation" : "C4.315","role": "TA","dayOff" :"Tuesday","department" :  "MET"} ]    

***

#### **Functionality** : view all the staff in a course in the HOD department   
**Route**: /hod/viewStaffinDepartmentByCourse       
**Request type**: GET  
**Request body**: {"courseName":"theory"}    
**Response body**: [{"id":"ac-5", "email" : "foo@guc.edu.eg","name" : "timo","officeLocation" : "C3.315","role": "HOD","dayOff" :"Tuesday","department" :  "MET"},{"id":"ac-6", "email" : "foo1@guc.edu.eg","name" : "mahdy","officeLocation" : "C4.315","role": "TA","dayOff" :"Tuesday","department" :  "MET"} ]      

***

#### **Functionality** : view the DaysOff for all staff in the HOD department  
**Route**: /hod/viewDayOffAllStaff       
**Request type**: GET     
**Response body**: array of json objects containing the id name and dayOff     

***

#### **Functionality** : view the DayOff for a single staff in the HOD department  
**Route**: /hod/viewDayOffSingleStaff         
**Request type**: GET  
**Request body**: {"id":"ac-5"}   
**Response body**: json object containing the id name and dayOff      

***

#### **Functionality** : view all the DayOff requests in the HOD department  
**Route**: /hod/viewDayOffRequests  
**Request type**: GET   
**Response body**:array of requests like { "senderId":"ac-1",
    "newday":"sunday", 
    "status":"pending",
    "department":"MET",  
    "SeenSender":false,
    "SeenReceiver":false}  

***

#### **Functionality** : view all the Leave requests in the HOD department  
**Route**: /hod/viewLeaveRequests  
**Request type**: GET  
**Response body**:array of requests like { "senderId":"ac-3",
    "typeOfLeave":"Accidental",
    "status":"pending",
    "startDate":"2020-10-19T03:34:55Z",
    "dayLimit":1,
    "periodOfLeave":1,
    "document":"document",
    "department":"MET",  
    "SeenSender":false,
    "SeenReceiver":false}  

***

#### **Functionality** : handle a CahngeDayOff request in the HOD department  
**Route**: /hod/handleDayOffRequests  
**Request type**: PUT  
**Request body**: {"requestId" : "5fe65679319caf97eceb9dbb","state":"accepted"} -> the state is only one of three 'accepted','pending','rejected'  
**Note**: the view route is what makes us first see this request and this will be handled correctly in front end  

***

#### **Functionality** : handle a Replacement request in the HOD department  
**Route**: /hod/handleReplacementRequest  
**Request type**: PUT  
**Request body**: {"requestId" : "5fe65679319caf97eceb9dbb","state":"accepted"}  -> the state is only one of three 'accepted','pending','rejected'  
**Note**: the view route is what makes us first see this request and this will be handled correctly in front end  

***

#### **Functionality** : handle a Leave request in the HOD department  
**Route**: /hod/handleLeaveRequests  
**Request type**: PUT  
**Request body**: {"requestId" : "5fe65679319caf97eceb9dbb","state":"accepted"}  -> the state is only one of three 'accepted','pending','rejected' 
**Note**: the view route is what makes us first see this request and this will be handled correctly in front end  

***

#### **Functionality** : view the coverage for a course in the HOD department  
**Route**: /hod/viewCourseCoverage  
**Request type**: GET  
**Request body**: {"courseName" : "theory"}  
**Response body**: Json object containing name and code and coverage of the course

***

#### **Functionality** : view teaching assignments of a course in the HOD department  
**Route**: /hod/viewTeachingAssignments  
**Request type**: GET  
**Request body**: {"courseName" : "theory"}  
**Response body**: array of Json objects each contains id and name and the slots of teaching 

***
### **Instructor**  
  
#### **Functionality**: View the coverage of course(s) he/she is assigned to.  
**Route**: /inst/viewCoverage  
**Request type**: GET   
**Response body**: Array of objects containing the code of the course and its coverage  
[  
    {  
        "courseCode": "DMET502",  
        "courseCoverage": 0  
    }  
]    
**Notes**:  
  
***  
#### **Functionality**: View the slots' assignment of course(s) he/she is assigned to.  
**Route**: /inst/viewAssignments  
**Request type**: GET   
**Response body**: Array of all the courses taught by this instructor: for each course the code of the course along with an array containing the slots of the course assigned to whom are shown .  
[  
    {  
        "courseCode": "DMET502",  
        "courseSlots": []  
    }  
]  
**Notes**:  
  
***  
#### **Functionality**:View all the staff in his/her department or per course along with their profles.  
**Route**: /inst/viewStaff  
**Request type**: GET   
**Request body**: Empty (for viewing all the staff in the department)  
OR   
{  
    "courseCode":"DMET502"  
}  
(for viewing the staff of a specific course)  
**Response body**:  
[  
    {  
        "ID": "ac-1",  
        "Name": "Rimon Elias",  
        "Email": "rimo@guc.edu.eg",  
        "Office Location": "C7.313",  
        "Gender": "male",  
        "Role": "Head Of Department (HOD) & Instructor",  
        "Dayoff": "Tuesday",  
        "Department": "Digital Media Engineering and Technology(DMET)"  
    },  
    {  
        "ID": "ac-5",  
        "Name": "Menna Khalifa",  
        "Email": "menna@guc.edu.eg",  
        "Office Location": "C7.220",  
        "Gender": "female",  
        "Role": "Course Coordinator & Teaching Assistant",  
        "Dayoff": "Sunday",  
        "Department": "Digital Media Engineering and Technology(DMET)"  
    }  
]  
**Notes**:  
if courseCode doesn't exist on the request body, all staff in the department will be returned.  
  
***  
#### **Functionality**: Assign an academic member to an unassigned slots in course(s) he/she is assigned to.  
**Route**: /inst/SlotAssignment  
**Request type**: POST  
**Request body**:   
{  
    "course":"DMET502",  
    "day":"Monday",  
    "slot":"2nd",  
    "location":"C3.102",
    "acadMem":"ac-7"  
}  
**Response body**:   
***  
  
#### **Functionality**: Update assignment of academic member in course(s) he/she is assigned to  
**Route**: /inst/SlotAssignment  
**Request type**: PUT  
**Request body**:   
{  
    "keyCourse":"",  
    "keyDay": "",  
    "keySlot":"",  
    "keyLoc":"",  
    "newAcadMem":""  
}  
**Response body**:   
**Notes**:  
  
***  
  
#### **Functionality**: Delete assignment of academic member in course(s) he/she is assigned to  
**Route**: /inst/SlotAssignment  
**Request type**: DELETE  
**Request body**:   
{  
    "keyCourse":"",  
    "keyDay": "",  
    "keySlot":"",  
    "keyLoc":""  
}  
**Response body**:   
**Notes**:  
***  
  
#### **Functionality**: Remove academic member
**Route**: /inst/removeAssignedMember
**Request type**: DELETE     
**Request body**:   
{   
    "course":"DMET502",  
    "acadMem":"ac-4"  
}  
**Response body**:   
**Notes**:  
  
***  
  
  
  
#### **Functionality**: Assign an academic member in each of his/her course(s) to be a course coordinator.  
**Route**: /inst/assignCoordinator  
**Request type**: POST  
**Request body**:   
{   
    "course":"DMET502",  
    "coordId":"ac-4"  
}  
**Response body**:   
**Notes**:  
  
***  
  
***  
### **Coordinator**    
#### **Functionality**: View "slot linking" request(s) from academic members linked to his/her course.    
**Route**: /cor/viewSlotRequests    
**Request type**: GET    
**Request body**:    
**Response body**:    
[
    {
        "_id": "5fe6529de4213849c0d5bb4c",
        "senderId": "ac-7",
        "courseId": "5fe52662b9236928c0d6f75d",
        "status": "accepted",
        "slot": "3rd",
        "day": "Tuesday",
        "SeenSender": false,
        "SeenReceiver": false,
        "location": "5fe52145b9236928c0d6f740",
        "__v": 0
    },
    {
        "_id": "5fe6587833e2e63cfc242334",
        "senderId": "ac-7",
        "courseId": "5fe52662b9236928c0d6f75d",
        "status": "pending",
        "slot": "4th",
        "day": "Wednesday",
        "SeenSender": false,
        "SeenReceiver": false,
        "location": "5fe52145b9236928c0d6f740",
        "__v": 0
    }
]
**Notes**:    
  
***  
  
#### **Functionality**: Accept "slot linking" requests from academic members linked to his/her course.    
**Route**: /cor/acceptSlotRequest    
**Request type**: PUT    
**Request body**:     
{
    "reqId":"5fe6529de4213849c0d5bb4c"
}
**Response body**:     
**Notes**:    
  
***   
  
#### **Functionality**: Reject "slot linking" requests from academic members linked to his/her course.    
**Route**: /cor/rejectSlotRequest    
**Request type**: PUT    
**Request body**:     
{
    "reqId":"5fe6529de4213849c0d5bb4c"
}
**Response body**:     

**Notes**:    
  
***  
  
#### **Functionality**: Add course slot(s) in his/her course.    
**Route**: /cor/courseSlot    
**Request type**: POST    
**Request body**:    
{   
    "course":"CSEN704",  
    "day":"Tuesday",  
    "slot":"2nd",  
    "location": "C7.304"  
}  
**Response body**:    
**Notes**:    
All 4 fields are required.
  
***  
  
#### **Functionality**: Update course slot(s) in his/her course.  
**Route**: /cor/courseSlot  
**Request type**: PUT  
**Request body**:   
{  
    "keyCourse":"DMET502",  
    "keyDay":"Sunday",  
    "keySlot":"3rd",  
    "keyLoc":"C3.102"
    "newLoc":"C3.101"  
}  
**Response body**:   

**Notes**:  
The only updatable field is location. the course,day,slot,location of the slot to be updated must be provided.
***  
  
#### **Functionality**: Delete course slot(s) in his/her course.  
**Route**: /cor/courseSlot  
**Request type**: DELETE  
**Request body**:   
{
    "keyCourse":"DMET502",
    "keyDay":"Tuesday",
    "keySlot":"1st",
    "keyLoc":"C3.102"
}
**Response body**:   

**Notes**:  


***  
  
