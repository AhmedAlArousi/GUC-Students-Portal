require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();

//routes
const initialRoutes=require('./routes/initialRoutes');
const staffRoutes=require('./routes/staffRoutes');
const hrRoutes=require('./routes/hrRoutes');    
const acRoutes=require('./routes/acRoutes');
const instructorRoutes=require('./routes/instructorRoutes');
const coordinatorRoutes=require('./routes/coordinatorRoutes');
const hodRoutes=require('./routes/hodRoutes');


app.use(cors())
app.use(express.json());

//middlewares
app.use('',initialRoutes);
app.use('/staff',staffRoutes);
app.use('/hr',hrRoutes);
app.use('/ac',acRoutes);
app.use('/cor',coordinatorRoutes);
app.use('/inst',instructorRoutes);
app.use('/hod',hodRoutes);


module.exports.app=app