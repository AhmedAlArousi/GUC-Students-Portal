const { required } = require('joi');
const Joi = require('joi');

const postSlotAssignment=Joi.object({
    course: Joi.string().required(),
    day: Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    slot: Joi.string().required().valid('1st', '2nd', '3rd', '4th', '5th'),
    location: Joi.string().required(),
    acadMem: Joi.string().required()
})
const putSlotAssignment=Joi.object({
    keyCourse: Joi.string().required(),
    keyDay: Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    keySlot: Joi.string().required().valid('1st', '2nd', '3rd', '4th', '5th'),
    keyLoc: Joi.string().required(),
    newAcadMem: Joi.string().required()
})
const deleteSlotAssignment=Joi.object({
    keyCourse: Joi.string().required(),
    keyDay: Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    keySlot: Joi.string().required().valid('1st', '2nd', '3rd', '4th', '5th'),
    keyLoc: Joi.string().required(),
})

const removeAssignedMember=Joi.object({
    course: Joi.string().required(),
    acadMem: Joi.string().required()
})
module.exports={
    postSlotAssignment: postSlotAssignment,
    putSlotAssignment: putSlotAssignment,
    deleteSlotAssignment: deleteSlotAssignment,
    removeAssignedMember: removeAssignedMember
}