//any missing schemes are redundant, they are having a single attr which is a string and required (stringId joi scheme)
const { required } = require('joi');
const Joi = require('joi');


//courseInsructor
const assignCourseToInstructor=Joi.object({
    id: Joi.string().required(),
    courseName: Joi.string().required()
})
const deleteCourseToInstructor=Joi.object({
    id: Joi.string().required(),
    courseName: Joi.string().required()
})
const updateCourseToInstructor=Joi.object({
    idOld: Joi.string().required(),
    idNew: Joi.string().required(),
    courseName: Joi.string().required()
})
// view staff
const viewStaff=Joi.object({
    courseName: Joi.string().required()
})
// view day off
const viewDaysOff=Joi.object({
    id: Joi.string().required()
})
// handle DayOff
const handleDayOff=Joi.object({
    requestId: Joi.string().required(),
    state: Joi.string().valid('accepted','pending','rejected')
})
// handle leave
const leaveRequset=Joi.object({
    requestId: Joi.string().required(),
    state: Joi.string().valid('accepted','pending','rejected')
})
// handle replacement
const replacementRequset=Joi.object({
    requestId: Joi.string().required(),
    state: Joi.string().valid('accepted','pending','rejected','','')
})
// view course coverage
const courseCoverage=Joi.object({
    courseName: Joi.string().required()
})

// view teachingAssignments
const teachingAssignments=Joi.object({
    courseName: Joi.string().required()
})

module.exports = {
    assignCourseToInstructor:assignCourseToInstructor,
    deleteCourseToInstructor:deleteCourseToInstructor,
    updateCourseToInstructor:updateCourseToInstructor,
    viewStaff:viewStaff,
    viewDaysOff:viewDaysOff,
    handleDayOff:handleDayOff,
    replacementRequset:replacementRequset,
    courseCoverage:courseCoverage,
    teachingAssignments:teachingAssignments,
    leaveRequset:leaveRequset
} 