const { required } = require('joi');
const Joi = require('joi');

const postCourseSlot=Joi.object({
    course: Joi.string().required(),
    day: Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    slot: Joi.string().required().valid('1st', '2nd', '3rd', '4th', '5th'),
    location: Joi.string().required()
})
const putCourseSlot=Joi.object({
    keyCourse: Joi.string().required(),
    keyDay: Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    keySlot: Joi.string().required().valid('1st', '2nd', '3rd', '4th', '5th'),
    keyLoc: Joi.string().required(),
    newloc: Joi.string().required()
})
const deleteCourseSlot=Joi.object({
    keyCourse: Joi.string().required(),
    keyDay: Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    keySlot: Joi.string().required().valid('1st', '2nd', '3rd', '4th', '5th'),
    keyLoc: Joi.string().required(),
})


module.exports={
    postCourseSlot: postCourseSlot,
    putCourseSlot: putCourseSlot,
    deleteCourseSlot: deleteCourseSlot

}