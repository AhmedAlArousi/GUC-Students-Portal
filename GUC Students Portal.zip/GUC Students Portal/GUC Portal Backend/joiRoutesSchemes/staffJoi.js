const Joi = require("joi");

// const joiStaffSchema  = Joi.object({
//     id:Joi.string().required(),
//     email:Joi.string().email().required(),
//     password:Joi.string().min(6).required(),
//     name:Joi.string().required(),
//     salary:Joi.number().required(),
//     gender: Joi.string().valid('male','female').required(),
//     officeLocation:Joi.string().required(),
//     role:Joi.string().valid('HR','instructor','TA','coordinator','HOD'),
//     annualLeaves:Joi.array().items(Joi.number()),
//     // signInLogs:Joi.array().object({
//     //     timeStamp : Joi.date().required(),
//     //     type : Joi.string().valid('in','out').required()
//     // }),
//     dayOff:Joi.string().required(),
//     coursesIds:Joi.array().object({
//         courseId : Joi.string().required()
//     }),
//     schedule: Joy.array().object({
//         day : Joi.string().valid('Sunday','Monday','Tuesday','Wednesday', 'Thursday', 'Friday', 'Saturday').required(),
//         slot : Joi.string().required(),
//         course : Joi.string().required(),
//         location : Joi.string().required()
//     })
//     ,
//     department : Joi.string().required()
// });

const signInNewPassJoi = Joi.object({
    newPassword : Joi.string().min(6).required()
})

const viewAttByMonth = Joi.object({
    month : Joi.string().required().valid('January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December')
})

const changeEmailJoi = Joi.object({
    newEmail : Joi.string().email({minDomainSegments: 2, tlds: { allow: ['com', 'net'] } }).required()
})


module.exports = {
    signInNewPassJoi : signInNewPassJoi,
    viewAttByMonth : viewAttByMonth,
    changeEmailJoi : changeEmailJoi
}