const Joi = require('joi');

const replacementJoi = Joi.object({
    receiverId : Joi.string().required(),
    Date : Joi.date().required(),
    reason : Joi.string().allow(''),
    slot : Joi.string().valid('','1st' , '2nd', '3rd' , '4th' , '5th')
})

const slotLinkingRequestJoi = Joi.object({
    courseCode : Joi.string().required(),
    slot : Joi.string().required().valid('1st' , '2nd', '3rd' , '4th' , '5th'),
    day : Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    location : Joi.string().required()
})

const changeDayOffJoi = Joi.object({
    newday : Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    reasonOfChange : Joi.string().allow(''),
    comment : Joi.string().allow('')
})

const leaveRequestJoi = Joi.object({
    typeOfLeave : Joi.string().required(),
    startDate : Joi.date().required(),
    periodOfLeave : Joi.number().required(),
    document : Joi.string().allow(''),
    reason : Joi.string().allow(''),
    compensatingDay: Joi.date().allow('')
})

module.exports = {
    replacementJoi : replacementJoi,
    slotLinkingRequestJoi : slotLinkingRequestJoi,
    changeDayOffJoi : changeDayOffJoi,
    leaveRequestJoi : leaveRequestJoi
}