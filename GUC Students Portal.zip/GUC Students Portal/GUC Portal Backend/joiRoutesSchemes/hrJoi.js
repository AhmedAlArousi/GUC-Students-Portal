//any missing schemes are redundant, they are having a single attr which is a string and required (stringId joi scheme)
const { required } = require('joi');
const Joi = require('joi');

//location
const postLocation=Joi.object({
    name: Joi.string().required(),
    type: Joi.string().required().valid('Office','Lab','hall','Tutorial Room'),
    curCapacity: Joi.number().min(0),
    maxCapacity: Joi.number().required().min(0)

})
const stringId= Joi.string().required()

const putLocation=Joi.object({
    key: Joi.string().required(),
    name: Joi.string(),
    curCapacity: Joi.number().min(0),
    maxCapacity: Joi.number().min(0)

}).min(2)
//faculty
const postFaculty=Joi.object({
    name: Joi.string().required(),
    code: Joi.string().required()

})
const putFaculty=Joi.object({
    key: Joi.string().required(),
    name: Joi.string(),
    code: Joi.string()

}).min(2)
//department
const postDepartment=Joi.object({
    name: Joi.string().required(),
    code: Joi.string().required(),
    facCode:Joi.string().required()

})
const putDepartment=Joi.object({
    key: Joi.string().required(),
    name: Joi.string(),
    code: Joi.string(),
    facCode: Joi.string(),
    headOfDepartmentId:Joi.string()
}).min(2)
//course
const postCourse=Joi.object({
    name: Joi.string().required(),
    code: Joi.string().required(),
    dep:Joi.string().required()

})
const deleteCourse=Joi.object({
    codeCourse: Joi.string().required(),
    codeDepartment: Joi.string().required()

})
const putCourse=Joi.object({
    key: Joi.string().required(),
    name: Joi.string(),
    code: Joi.string()
}).min(2)
//member
const postMember=Joi.object({
    name: Joi.string().required(),
    email: Joi.string().email().required(),
    salary:Joi.number().required().min(0),
    gender:Joi.string().required().valid('male','female'),
    dayOff:Joi.string().required().valid('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday'),
    role:Joi.string().required().valid('TA','HR','HOD','instructor','coordinator'),
    officeLocation:Joi.string().required(),
    department:Joi.string().allow('')

})
const putMember=Joi.object({
    id: Joi.string().required(),
    salary:Joi.number().min(0),
    role:Joi.string().valid('TA','HR','HOD','instructor','coordinator'),
    officeLocation:Joi.string(),
    department:Joi.string()
}).min(2)
//sign in/out rec
const postRecord=Joi.object({
    id: Joi.string().required(),
    timeStamp: Joi.date().required(),//q
    type:Joi.string().required().valid('in','out')

})
//update salary
const putSalary=Joi.object({
    id: Joi.string().required(),
    salary:Joi.number().min(0).required()
})
module.exports = {
    postLocation:postLocation,
    putLocation:putLocation,
    postFaculty:postFaculty,
    putFaculty:putFaculty,
    postDepartment:postDepartment,
    putDepartment:putDepartment,
    postCourse:postCourse,
    deleteCourse:deleteCourse,
    putCourse:putCourse,
    postMember:postMember,
    putMember:putMember,
    postRecord:postRecord,
    putSalary:putSalary,
    stringId:stringId
} 