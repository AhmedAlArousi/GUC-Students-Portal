const { urlencoded } = require('express');//lab before mid
require('dotenv').config({ path: '.env' });
const {app} = require('./app');
//////////mongo connection///////////
const mongoclient=require('mongodb').MongoClient;
const mongoose=require('mongoose');
const url_test=process.env.URL_MONGO;

mongoose.connect(url_test).then(async()=>{
    console.log('db is connected to mongoose atlas successfully')

const port = process.env.PORT || 3000;
app.listen(port,()=>{
    console.log("connected succsefully to the port")
})

}).catch((err)=>{ 
 console.log(err)
})
