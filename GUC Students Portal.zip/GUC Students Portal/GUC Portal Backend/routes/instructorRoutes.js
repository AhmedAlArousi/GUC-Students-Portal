const express= require('express');
const router= express.Router()
//models needed

//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken')
const blackListedTokens = require('../models/TokenBlackList')

const staffModel= require('../models/staff');
const courseModel= require('../models/Course');
const depModel = require('../models/Department');
const locationModel = require('../models/location');

const instJoi=require('../joiRoutesSchemes/instructorJoi')

const helpers = require('../Functions/instFuncts');

//auth
const instAuth=async (req,res,next)=>{
    try{    
        const token=req.header("token");//header in log in post request (postman)
        const isValidToken = await blackListedTokens.findOne({jwt : token})
        if(isValidToken){
            return res.status(401).json({msg:"Not signed in"});
        }
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const role=member.role;
        if(role=='instructor' || role =='HOD')next();
        else return res.status(401).json({err:"No access rights"});
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
}

//routes start here

router.route('/viewCoverage')
.get(instAuth, async(req, res)=> {
    try {
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const staff= await staffModel.findOne({"id": verified.id});
        
        const arr=staff.coursesIds;
        //console.log(arr);
        const result = await Promise.all(arr.map(async function(courseIdObj){
            //console.log('Entry: ',courseIdObj);
            courseId = courseIdObj.courseId;
            //console.log('Attr: ',courseId);
            const courseDocument = await courseModel.findOne({_id:courseId});
            //console.log('CrsDoc: ',courseDocument);
            const courseCode = courseDocument.code;
            const courseCoverage = courseDocument.coverage;
            //console.log('Cod&cvr ',courseCode, courseCoverage)
            return {courseCode: courseCode, courseCoverage: courseCoverage};//will this work ?
        }));
        //console.log('Res: ', result);
        res.status(200).send(result);

    }
    catch(err){
        console.log('Errrorrrr');
        return res.status(500).json({err:err.message});
    }

})


router.route('/viewAssignments')
.get(instAuth, async(req, res)=> {
    try {
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const staff= await staffModel.findOne({"id": verified.id});
        
        const arr=staff.coursesIds;
        const result = await Promise.all(arr.map(async function(courseIdObj){
            const courseDocument = await courseModel.findOne({_id: courseIdObj.courseId});
            const courseCode = courseDocument.code;
            const courseSlots = courseDocument.slots;
            return {courseCode: courseCode, courseSlots: courseSlots}; //will this work ?
        }));
        return res.status(200).send(result);
    }
    catch(err){
        console.log(err);
        return res.status(500).json({err:err.message});
    }
})


router.route('/viewStaff')
.get(instAuth, async(req, res)=> {
    try {
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const staff= await staffModel.findOne({"id": verified.id});
        
        // const type = req.body.type;
        // const crsCode = req.body.courseId;
        
        const dep = staff.department;
        const depDoc = await depModel.findOne({_id: dep});
        const depStaff = await staffModel.find({department: depDoc.id});
        if (!req.body.hasOwnProperty("courseCode")){
            // console.log("hi1")    
            return res.status(200).send(await Promise.all(depStaff.map(helpers.viewProfile)));
        }
        else{
            const crsCode = req.body.courseCode;
            const crsDoc = await courseModel.findOne({code: crsCode});
            if(!crsDoc){
                return res.status(406).json({err:"This course doesn't exist"})
            }
            // const courseStaff = await staffModel.find({courseIds:{courseId:crsDoc._id}});
            const courseStaff = depStaff.filter(function(person){
                const carr = person.coursesIds;
                for (var i=0; i<carr.length;i++){
                    if (carr[i].courseId == crsDoc.id){
                        return true;
                    }
                }
                return false;
            });
            return res.status(200).send(await Promise.all(courseStaff.map(helpers.viewProfile(elem))));
        }
    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }
})

router.route('/SlotAssignment')
.post(instAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id=member.id;//req.body.id;
        
        await instJoi.postSlotAssignment.validateAsync(req.body);
        //check the input course exists
        const course = req.body.course;
        const courseDoc = await courseModel.findOne({code:course}); 
        if (!courseDoc){
            return res.status(406).json({err:"This course doesn't exist"});
        }
        
        //check this instructor teaches this course   
        const staff=await staffModel.findOne({id:id});
        if(!staff.coursesIds.find(elem => elem.courseId==courseDoc.id)){
            return res.status(401).json({err:"This course cannot be modified by this instructor"});
        }

        const slotDay = req.body.day;
        const slotNum = req.body.slot;
        const slotLoc = req.body.location; 
        if(slotLoc==='' || slotLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }
        const slotLocDoc = await locationModel.findOne({name:slotLoc});
        if (!slotLocDoc){
            //slotLoc = 'N/A';
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        const slotLocId = slotLocDoc.id;

        //validate  the input id
        const acadMem = req.body.acadMem;
        const acadMemDoc = await staffModel.findOne({id:acadMem});
        //console.log(acadMemDoc);
        if(!acadMemDoc){
            return res.status(406).json({err:"Academic member to be assigned to the slot doesn't exist"});
        }
        if(acadMemDoc.role=="HR"){
            return res.status(406).json({err:"You cannot assign a slot to an HR"});
        }
        if(!acadMemDoc.coursesIds.find(elem => elem.courseId==courseDoc.id)){
            acadMemDoc.coursesIds.push({courseId:courseDoc.id});
        }
        
        var crsSet = 0;
        const courseSlots = courseDoc.slots;
        const oldNumS = courseSlots.length;
        const oldOccup = oldNumS * courseDoc.coverage;
        
        for (var i=0; i<courseSlots.length; i++){
            if (courseSlots[i].day==slotDay && courseSlots[i].slot==slotNum
                && courseSlots[i].location==slotLocId){

                if (courseSlots[i].academic!='N/A'){
                    return res.status(400).json({err:"This slot is already assigned to someone else"});
                }
                else{
                    courseSlots[i].academic=acadMem;
                    crsSet++; 
                }
            }
        }

        courseDoc.coverage = 100*(oldOccup+crsSet)/(courseSlots.length);
        var stfSet = 0;
        let staffSched = acadMemDoc.schedule;
        for (var i=0; i<staffSched.length;i++){
            if (staffSched[i].day==slotDay && staffSched[i].slot==slotNum
                && staffSched[i].location==slotLocId){
                if (staffSched[i].course!='N/A'){
                    return res.status(400).json({err:"This academic member is already busy at this slot"});
                }
                else{
                    staffSched[i].location = slotLocId;
                    staffSched[i].course = courseDoc.id;
                    stfSet++;
                }
            }
        }
        console.log(slotLoc);
        if(!stfSet){
            staffSched.push({day:slotDay, slot:slotNum, location: slotLocId, course: courseDoc.id});
            stfSet++;
        }
        
        if (!crsSet || !stfSet ){
            res.status(400).send("wrong slot");
        }
        else{
            await courseDoc.save();
            await acadMemDoc.save()
            return res.status(200).json({msg:"Succsessfully assigned this slot to this staff member"});
        }

        

    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})
.put(instAuth, async(req, res)=>{
    try{
        //replace the acMember assigned to a slot with a different ac member
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id=member.id;//req.body.id;
        // const staff= member;//await staffModel.findOne({id:id});
        
        await instJoi.putSlotAssignment.validateAsync(req.body);
        
        const keyDay = req.body.keyDay;
        const keySlot = req.body.keySlot;
        
        const keyCourse = req.body.keyCourse;
        const keyCourseDoc = await courseModel.findOne({code:keyCourse}); 
        if (!keyCourseDoc){
            return res.status(406).json({err:"This course doesn't exist"});
        }
        
        const keyLoc = req.body.keyLoc; 
        if(keyLoc==='' || keyLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }
        const keyLocDoc = await locationModel.findOne({name:keyLoc});
        if (!keyLocDoc){
            //slotLoc = 'N/A';
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        const keyLocId = keyLocDoc.id;



        //check this instructor teaches this course 
        const staff=await staffModel.findOne({id:id});
        if(!staff.coursesIds.find(elem => elem.courseId==keyCourseDoc.id)){
            return res.status(406).json({err:"This course cannot be modified by this instructor"});
        }

        const newAcadMem = req.body.newAcadMem;
        const newAcadMemDoc = await staffModel.findOne({id:newAcadMem});
        if(!newAcadMemDoc){
            return res.status(406).json({err:"The new academic member doesn't exist"});
        }

        var crsSet = 0;
        const courseSlots = keyCourseDoc.slots;
        for (var i=0; i<courseSlots.length; i++){
            if (courseSlots[i].day==keyDay && courseSlots[i].slot==keySlot
                && courseSlots[i].location==keyLoc){
                if(courseSlots[i].academic=='N/A'){
                    return res.status(406).json({err:"This slot is unassigned. You should use POST request"});
                }
                let oldAcadMem = courseSlots[i].academic;
                courseSlots[i].academic=newAcadMem;
                crsSet++;
            }
        }

        const newSched = newAcadMemDoc.schedule;
        var stfSet = false;
        for (var i=0; i<newSched.length&&!stfSet;i++){
            if (newSched[i].day==keyDay && newSched[i].slot==keySlot){
                if (newSched[i].course!='N/A'){
                    return res.status(400).json({err:"This new academic member is already busy at this slot"});
                }
                else{
                    newSched[i].location = keyLoc;
                    newSched[i].course = keyCourseDoc.id;
                    stfSet = true;
                }
            }
        }
        if(!stfSet){
            newSched.push( {day:keyDay, slot:keySlot, location: keyLoc, course: keyCourseDoc.id} )
            stfSet = true;
        }
        const oldAcadDoc = await staffModel.findOne({id:oldAcad});
        const oldSched = oldAcadMemDoc.schedule;
        var oldRmv = false;
        for (var i=0; i<newSched.length&&!oldRmv;i++){
            if (oldSched[i].day==keyDay && oldSched[i].slot==keySlot &&
                oldSched[i].location==keyLocId){
                oldSched.splice(i,1);
                i--;
                oldRmv=true;
            }
        }


        if (!crsSet || !stfSet || !oldRmv){
            return res.status(500).json({err:"Something went wrong"});
        }
        else{
            await keyCourseDoc.save();
            await oldAcadDoc.save();
            await newAcadMemDoc.save();
            return res.status(200).json({msg:"Succsessfully updated this slot(s) to this new academic member"});
        }


    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }
})
.delete(instAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id=member.id;//req.body.id;
        // const staff= member;//await staffModel.findOne({id:id});
        await instJoi.deleteSlotAssignment.validateAsync(req.body);

        const keyDay = req.body.keyDay;
        const keySlot = req.body.keySlot;
        const keyCourse = req.body.keyCourse;
        const keyCourseDoc = await courseModel.findOne({code:keyCourse}); 
        if (!keyCourseDoc){
            res.status(406).json({err:"This course doesn't exist"});
        }
        
        const keyLoc = req.body.keyLoc; 
        if(keyLoc==='' || keyLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }
        const keyLocDoc = await locationModel.findOne({name:keyLoc});
        if (!keyLocDoc){
            //slotLoc = 'N/A';
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        const keyLocId = keyLocDoc.id;
        
        //check this instructor teaches this course 
        const staff=await staffModel.findOne({id:id});
        if(!staff.coursesIds.find(elem => elem.courseId==keyCourseDoc.id)){
            return res.status(406).json({err:"This course cannot be modified by this instructor"});

        }

        var sltClr = 0;
        const courseSlots = keyCourseDoc.slots;
        const oldNumS = courseSlots.length;
        const oldOccup = oldNumS * keyCourseDoc.coverage;
        const delStf = [];
        for (var i=0; i<courseSlots.length; i++){
            if (courseSlots[i].day==keyDay && courseSlots[i].slot==keySlot
                &&courseSlots[i].location==keyLocId){
                delStf.push(courseSlots[i].academic);
                courseSlots.splice(i,1);
                i--;
                sltClr++;
            }
        }
        courseDoc.coverage = (oldOccup-sltClr)/(courseSlots.length);
        for (var i=0;i<delStf.length;i++){
            const oldAcad = delStf[i];
            if(oldAcad=='N/A') continue;
            const oldAcadDoc = await staffModel.findOne({id:oldAcad});
            const oldSched = oldAcadMemDoc.schedule;
            // var oldRmv = 0;
            for (var i=0; i<oldSched.length;i++){
                if (oldSched[i].day==slotDay && oldSched[i].slot==slotNum 
                    && oldSched[i].location==keyLocId){
                    oldSched.splice(i,1);
                    i--;
                    // oldRmv++;
                }
            }
            
            await oldAcadDoc.save();
        }


        if (!sltClr){// ||  !oldRmv){
            return res.status(200).send({msg:"No matches to delete"});//(500).send("Something went wrong");
        }
        else{
            await courseDoc.save();
            // await oldAcadDoc.save();
            return res.status(200).json({msg:"Succsessfully deleted this slot(s)"});
        }

    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }
})

router.route('/removeAssignedMember')
.delete(instAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id=member.id;//req.body.id;
        // const staff= member;//await staffModel.findOne({id:id});
        
        await instJoi.removeAssignedMember.validateAsync(req.body);

        const course = req.body.course;
        const courseDoc = await courseModel.findOne({code:course}); 
        if (!courseDoc){
            return res.status(406).json({err:"This course doesn't exist"});
        }

        //check this instructor teaches this course 
        const staff=await staffModel.findOne({id:id});
        if(!staff.coursesIds.find(elem => elem.courseId==courseDoc.id)){
            return res.status(406).json({err:"This course cannot be modified by this instructor"});
        }

        const acad = req.body.acadMem;
        const acadDoc = await staffModel.findOne({id:acad});
        if(!acadDoc){
            return res.status(406).json({err:"This id doesn't exist"});
        }
        if(!acadDoc.coursesIds.find(elem => elem.courseId==courseDoc.id)){
            return res.status(406).json({err:"This id doesn't teach this course"});
        }

        // var crsSet = false;
        const courseSlots = courseDoc.slots;
        for (var i=0; i<courseSlots.length; i++){
            console.log(courseSlots[i].academic, acad);
            if (courseSlots[i].academic ==acad){
                courseSlots[i].academic="N/A";
                // crsSet=true;
            }
        }

        const sched = acadDoc.schedule;
        var oldRmv = false;
        for (var i=0; i<sched.length;i++){
            if (sched[i].course==courseDoc.id){
                sched.splice(i,1);
                i--;
                oldRmv=true;
                break;
            }
        }

        acadDoc.coursesIds = acadDoc.coursesIds.filter(function(ob){
            return (ob.courseId != courseDoc.id)
        });

        // if (!crsSet){
        //     return res.status(500).json({err:"Something went wrong"});
        // }
        // else{
        await courseDoc.save();
        await acadDoc.save();
        return res.status(200).json({msg:"Succsessfully deleted to this  academic member"});
        // }
    }
    catch(err){
        // console.log("Error");
        return res.status(500).json({err:err.message});
    }
})

router.route('/assignCoordinator')
.post(instAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id=member.id;//req.body.id;
        // const staff= member;//await staffModel.findOne({id:id});
        
        const courseCode = req.body.course;
        const courseDoc = await courseModel.findOne({code: courseCode});
        if(!courseDoc){
            return res.status(406).json({err:"This course doesn't exist"});
        }
        if(!member.coursesIds.find(elem => elem.courseId==courseDoc.id)){
            return res.status(401).json({err:"This course cannot be modified by this instructor"});
        }
        //if this academicMember doesn't have this course in his courses, add it
        const newCord = req.body.coordId;
        let newCordDoc = await staffModel.findOne({id: newCord});
        if(!newCordDoc){
            return res.status(406).json({err:"This id of new coordinator doesn't exist"})
        }
        if(!newCordDoc.coursesIds.find(elem => elem.courseId==courseDoc.id)){
            newCordDoc.coursesIds.push({courseId:courseDoc.id});
        }
        if (newCordDoc.role!='TA' && newCordDoc.role!='coordinator'){
            return res.status(406).json({err: "The id entered to be coordinator isn't eligible for this role (he is either not a TA/coordinator)"})
        }
        newCordDoc.role='coordinator';
        
        courseDoc.coordinatorId = newCord;
        
        await newCordDoc.save();
        await courseDoc.save();

        return res.status(200).json({msg:'Successfully assigned this new course coordinator!'})
        
    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }
})

module.exports= router