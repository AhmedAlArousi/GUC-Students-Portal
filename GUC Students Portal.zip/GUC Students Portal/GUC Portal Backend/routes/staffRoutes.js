const express= require('express');
const router= express.Router()
//models needed
const staffModel= require('../models/staff');
const departmentModel= require('../models/Department');
const facultyModel= require('../models/Faculty')
const CourseModel= require('../models/Course')
//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken')
const staffFuncts = require("../Functions/staffFuncts")
const blackListedTokens = require('../models/TokenBlackList')
const staffJoi=require('../joiRoutesSchemes/staffJoi')
//routes start here
router.use('/',async(req,res,next)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const isValidToken = await blackListedTokens.findOne({jwt : token})
        if(!token || isValidToken){
            return res.status(401).json({msg:"Not signed in"});
        }
        const result= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const user = await staffModel.findOne({"id": result.id});
        req.user = user;
        next();
    }catch(err){
       return res.status(403).json({err:err.message});
    }
})

router.route('/logout')
.get(async (req,res)=> {
    try{
        //delete req.headers;
        const token=req.header("token");
        const newBlackListedToken = new blackListedTokens({
            jwt : token
        })
        await newBlackListedToken.save();
        res.send("Logged out")
    }
    catch(err) {
        res.status(500).json({err:err.message})
    }
})

router.route('/getUserData')
.get(async (req,res)=> {
    try{
        const user = req.user;
        const data = {
            name : user.name,
            ID : user.id,
            role : user.role,
            email : user.email
        }
        res.send(data);
    }
    catch(err) {
        res.status(500).json({err:err.message})
    }
})

router.route('/viewProfile')
.get(async(req,res) => {
    try{
        const user = req.user
        let result = [];
        user.signInLogs.forEach(log => result.push({
            Date : log.timeStamp.toUTCString(),
            Type : log.type
        }));
        const myProfile = {
            "ID" : user.id,
            "Email": user.email,
            "Name" : user.name,
            "Password" : user.password,
            "Gender": user.gender,

            "Role": user.role,
            "Salary": user.salary,
            
            "Office location": user.officeLocation,
            "Schedule": user.schedule,
            

            "Annual Leaves": user.annualLeaves,
            "Sign-in logs": result,
            "Off day": user.dayOff,
        }
        let myCourses = [];
        user.coursesIds.forEach(async elem => {
            const course = await CourseModel.findOne({_id : elem.courseId})
            myCourses.push(course);
        })
        myProfile["My courses"] = myCourses.length == 0 ? 'N/A' : myCourses;
        myProfile.Department = "N/A";
        myProfile.Faculty = "N/A";
        if(user.role != "HR"){
            if(user.department != 'N/A'){
                const department = await departmentModel.findOne({_id : user.department })
                const entry= await facultyModel.findOne({_id : department.facultyId});
                myProfile.Department = department.name + "  (" + department.code + ")";
                myProfile.Faculty = entry.name + "  (" + entry.code + ")";
            }     
        }
        res.send(myProfile);
    }
    catch(err){
        res.status(500).json({err:err.message})
    } 
})

router.route('/updateProfile')
.put(async(req,res) => {
    try{
        let user = req.user;
        const mail = req.body.email
        if(mail == ''){
            res.send("Cannot update empty mail")
        }
        else{ 
            await staffJoi.changeEmailJoi.validateAsync({newEmail : mail});
            const mailFound = await staffModel.findOne({"email" : mail})
            if(!mailFound){
                user.email = mail;
                await user.save();
                //res.send("Your email has changed to : " + user.email)
                res.send(user.email)
            }else{
                res.send("This email already in use");
            }  
        }
    }
    catch(err){
        res.status(500).json({err:err.message});
    }
})

router.route('/resetPassword')
.put(async(req,res)=>{
    try{
        const user = req.user;
        const salt = await bcrypt.genSalt(10);
        let oldPass = req.body.oldPassword
        if(oldPass == ''){
            return res.send("please enter your old password")
        }
        let correctPass = await bcrypt.compare(oldPass, user.password)
        if(!correctPass){return res.status(400).json("Old password is not correct");}
        if(req.body.newPassword.length < 6){
            return res.status(400).json("New password must has at least 6 charachters");
        }
        const newPasswordd = await bcrypt.hash(req.body.newPassword,salt);    
        user.password = newPasswordd;
        await user.save();
        res.send("Your password has changed successfully");
    }
    catch(err){
        res.status(500).json({err:err.message});
    }

})

router.route('/signIn')
.post(async(req,res)=>{
    try {
        const user = req.user;
        let date = new Date();
        if(date.getDay() == 5){
            return res.status(500).json({err : 'Cannot sign in on Friday'})
        }
        if(date.getHours() < 7){
            date.setUTCHours(7,0,0,0);
            res.status(200).json({msg: "Signed in successfully, Hours before 7 am are neglected"});
        }
        if(date.getHours() >= 19) {return res.status(400).json({err: "Sign in after 7pm is neglected"});}
        user.signInLogs.push({
            timeStamp : date,
            type : 'in'
        })
        res.status(200).json({msg: "Signed in successfully"});
        await user.save()
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})

router.route('/signOut')
.post(async(req,res)=>{
    try {
        const user = req.user;
        let date = new Date();
        if(date.getDay() == 5){
            return res.status(500).json({err : 'Cannot sign out on Friday'})
        }
        if(date.getHours()>=19){
            user.signInLogs.push({
                timeStamp : date.setUTCHours(19,0,0,0),
                type : 'out'
            })
            await user.save()
            return  res.status(200).json({msg: "Signed out successfully, Hours after 7 pm are neglected"});
        }
        if(date.getHours() < 7) {return res.status(400).json({err: "Sign out before 7am is neglected"});}
        user.signInLogs.push({
            timeStamp : date,
            type : 'out'
        })
        res.status(200).json({msg: "Signed out successfully"});
        await user.save()
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})

router.route('/viewAttendance')
.get(async(req,res)=>{
    try {
        const user = req.user;
        let result = [];
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        user.signInLogs.sort(function(a,b){
            return new Date(b.timeStamp) - new Date(a.timeStamp);
        });
        let index = 0;
        for (log of user.signInLogs){
            let seconds = log.timeStamp.getSeconds();
            let minutes = log.timeStamp.getMinutes();
            let hour = log.timeStamp.getUTCHours();
            let x = hour >= 12 ? 'PM' : 'AM'
            let xy = hour < 10 ? '0' : '';
            let y = minutes < 10 ? '0' : '';
            let yx = seconds < 10 ? '0' : '';
            let time = xy + hour + ":" + y + minutes +':' + yx + seconds + " " + x;
            result.push({
            id : index,
            Type : log.type,
            DayName : days[log.timeStamp.getDay()] + " " + log.timeStamp.getDate(),
            Month : monthNames[log.timeStamp.getMonth()],
            YearNo : log.timeStamp.getFullYear(),
            Time : time, 
            })
            index++;
        }
        res.send(result)
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})

router.route('/viewAttendanceBymonth')
.get(async(req,res)=>{
    try {
        const user = req.user;
        //res.send(user.signInLogs)
        let month = req.body.month;
        await staffJoi.viewAttByMonth.validateAsync({ month : month});
        month = month.toLowerCase()
        const monthNames = ["january", "february", "march", "april", "may", "june",
        "july", "august", "september", "october", "november", "december"];
        let logs = user.signInLogs.filter(log => log.timeStamp.getMonth() == monthNames.indexOf(month))
        logs.sort(function(a,b){
            return new Date(a.timeStamp) - new Date(b.timeStamp);
        });
        let result = []
        logs.forEach(log => result.push({
            Date : log.timeStamp.toUTCString(),
            Type : log.type
        }));
        res.send(result)
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})

router.route('/viewMissingDays')
.get(async(req,res)=>
{
    try {
        const user = req.user;
        const missingDays = await staffFuncts.viewMissingDays(user);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        missingDays.sort(function(a,b){
            return new Date(b) - new Date(a);
        });
        let result = [];
        let index = 0;
        for (log of missingDays){
            result.push({
            id : index,
            DayName : days[log.getDay()] + " " + log.getDate(),
            Month : monthNames[log.getMonth()],
            YearNo : log.getFullYear(),
            })
            index++;
        }
        res.send(result)
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})

router.route('/viewMissingHours')
.get(async(req,res) => {
    try{
        const user = req.user;
        const no = await staffFuncts.viewMissingHours(user);
        const ans = {
        Missinghours : no.missingHours,
        ExtraHours : no.extraHours
        }
        res.send(ans);
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})

router.route('/viewSalaryDeduction')
.get(async(req,res) => {
    try{
        const user = req.user;
        const missingDays = await staffFuncts.viewMissingDays(user);
        const missingMinutes = await staffFuncts.viewMissingHours(user);
        let x;
        let missingDaysDeduction = (missingDays.length*user.salary) / 60;
        let missingMinDeduction = missingMinutes.missingHours - missingMinutes.extraHours;
        let totalDeduction;
        if(missingMinDeduction < 2.59){
            totalDeduction = missingDaysDeduction;
            x = parseFloat(totalDeduction).toFixed(2);
        }
        else{
            let netMin = missingMinDeduction - 2.59;
            let mins = netMin - Math.floor(netMin);
            let hrs = Math.floor(netMin);
            totalDeduction = (missingDaysDeduction + 60*60*mins*(user.salary/180) + (hrs*user.salary)/60);
            x = parseFloat(totalDeduction).toFixed(2);
        }
        console.log(x)
        res.sendStatus(x);
    }
    catch(err) {
        res.status(500).json({err:err.message});
    }
})


//abdallah
router.route('/course')
.get(async(req, res)=>{
    let result=await CourseModel.find({});
    let deps=await departmentModel.find({});
    for(let i=0;i<result.length;i++){
        let department=result[i].mainDepartment;
        if(result[i].mainDepartment!='N/A'){
            let x= await departmentModel.findOne({_id:result[i].mainDepartment});
            department=x.code;
        }
        result[i].mainDepartment=department;
        let cid=result[i].id;
        let mydeps=[];
        
        for(let j=0;j<deps.length;j++){

            for(let k=0;k<deps[j].coursesIds.length;k++){
                ///console.log(deps[j].coursesIds.courseId)
                if(deps[j].coursesIds[k].courseId==cid){
                    mydeps.push(deps[j].code);
                    break;
                }
            }
        }
        //console.log(mydeps)
        result[i]={...result[i],deps:mydeps}
    }
    //console.log(result)
    res.send(result);
})

module.exports=router;