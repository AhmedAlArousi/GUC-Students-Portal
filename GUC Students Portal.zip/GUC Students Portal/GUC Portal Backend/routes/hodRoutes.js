const express= require('express');
const router= express.Router()
//models needed
const courseModel= require('../models/Course');
const departmentModel= require('../models/Department');
const staffModel= require('../models/staff');
const locationModel= require('../models/location');
const ChangeDayOffModel= require('../models/ChangeDayOff');
const LeaveRequestModel= require('../models/LeaveRequest');

//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken')
const tokenSecret="adfeafafaef";
const blackListedTokens = require('../models/TokenBlackList')
//require joi
const Joi = require('joi');
const hodJoi=require('../joiRoutesSchemes/hodJoi')

//auth
const hodAuth=async (req,res,next)=>{
    try{    
        const token=req.header("token");//header in log in post request (postman)
        const isValidToken = await blackListedTokens.findOne({jwt : token})
        if(isValidToken){
            return res.status(401).json({msg:"Not signed in"});
        }
        const verified= jwt.verify(token,process.env.tokenSecret);

        const member= await staffModel.findOne({"id": verified.id});
        const role=member.role;
        if(role=='HOD')
        next();
        else return res.status(401).json({err:"No access rights"});
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
}

//routes start here
router.route('/courseInstructor')
.post(hodAuth,async(req, res)=>{//assigning a course instructor to a course
    try{
        const body=req.body;
        await hodJoi.assignCourseToInstructor.validateAsync(body);
        const id=body.id;
        const courseName=body.courseName;
        const member= await staffModel.findOne({"id": id});  
        const course= await courseModel.findOne({"name": courseName});  
        if(!course)
           return res.status(400).json({err:"course is not found"});
        if(!member)
            return res.status(400).json({err:"instructor is not found"});
        let check="false"
        let coursesIds= member.coursesIds;
        coursesIds.forEach(findElement);
        function findElement(value){
            if(value.courseId==course.id)
                 check="true"
        }
        if(check=="true")
           return res.status(400).json({err:"the instructor is already assigned to the course"});
        if(member.role!="instructor" && member.role!="HOD")
           return res.status(400).json({err:"this person is not an instructor"});
        member.coursesIds.push({"courseId":course.id});
        await member.save();
        res.status(200).json({msg:"Assigned successfully"});
     }catch(err){
        return res.status(500).json({err:err.message});
     }
})
.delete(hodAuth,async(req, res)=>{//delete a course from a course instructor 
    try{
        const body=req.body;
        await hodJoi.deleteCourseToInstructor.validateAsync(body);
        const id=body.id;
        const courseName=body.courseName;
        const member = await staffModel.findOne({"id": id});   
        if(!member)
            return res.status(400).json({err:"instructor is not found"});
        const course= await courseModel.findOne({"name": courseName});  
        if(!course)
            return res.status(400).json({err:"course is not found"});
        if(member.role!="instructor" && member.role!="HOD")
            return res.status(400).json({err:"this person is not an instructor"});
        let coursesIds = member.coursesIds;
        let index=0;
        let flag="false";
        const courseId=course.id;
        coursesIds.forEach(findElement);
        function findElement(value){
            if(value.courseId==courseId)
               flag="true";
            if(flag=="false")
               index++;
        }
        if(flag=="false")
           return res.status(400).json({err:"instructor is not assigned to the course already"});
        coursesIds.splice(index,1);
        for(let i=0;i<course.slots.length;i++){
            if(course.slots[i].academic==id){
                course.slots[i].academic="N/A"
            }
        }
        member.schedule=member.schedule.filter(slot=>slot.course!=courseId)

        await member.save();
        await course.save();
        res.status(200).json({msg:"deleted successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.put(hodAuth,async(req, res)=>{//updating a course instructor assigned to a course to another instructor
    try{
        const body=req.body;
        await hodJoi.updateCourseToInstructor.validateAsync(body);
        const idOld=body.idOld;
        const idNew=body.idNew;
        const courseName=body.courseName;
        const memberOld = await staffModel.findOne({"id": idOld});   
        const memberNew = await staffModel.findOne({"id": idNew}); 
        if(!memberOld)
            return res.status(400).json({err:"Old instructor is not found"});
        if(!memberNew)
            return res.status(400).json({err:"New instructor is not found"});
        const course= await courseModel.findOne({"name": courseName});  
        if(!course)
            return res.status(400).json({err:"course is not found"});
        const courseId=course.id;
        if(memberOld.role!="instructor" && memberOld.role!="HOD")
            return res.status(400).json({err:"Old person is not an instructor"});
        if(memberNew.role!="instructor" && memberNew.role!="HOD")
            return res.status(400).json({err:"New person is not an instructor"});
        let coursesIdsNew= await memberNew.coursesIds;
        let check="false"
        coursesIdsNew.forEach(findElementNew)
       
        function findElementNew(value){
            if(value.courseId==courseId)
                 check="true"
        }
        if(check=="true")
           return res.status(400).json({err:"the New instructor is already assigned to the course"});
       
        let coursesIdsOld= await memberOld.coursesIds;
        let index=0;
        let flag="false";
        coursesIdsOld.forEach(findElementOld);
        function findElementOld(value){
            if(value.courseId==courseId)
               flag="true";
            if(flag=="false")
            index++;
        }
        if(flag=="false")
           return res.status(400).json({err:"Old instructor is not assigned to the course already"});
        coursesIdsOld.splice(index,1);
        await  memberNew.coursesIds.push({"courseId":courseId});

        for(let i=0;i<course.slots.length;i++){
            if(course.slots[i].academic==idOld){
                course.slots[i].academic="N/A"
            }
        }
        memberOld.schedule=memberOld.schedule.filter(slot=>slot.course!=courseId)

       // await member.save();
        await course.save();
        await memberOld.save();
        await memberNew.save();
        res.status(200).json({msg:"updated successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/viewStaffinDepartment')
.get(hodAuth,async(req, res)=>{//view staff in my department
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        let members =await staffModel.find({"department":member.department});
        const dep=await departmentModel.findOne({"_id":member.department});
        for (let i=0;i<members.length;i++){
        //    console.log(members[i].password);
            members[i].password='XXXXXXXXXXX'
            members[i].department=dep.name;
            if(members[i].officeLocation!='N/A')
            members[i].officeLocation=(await locationModel.findOne({"_id":members[i].officeLocation})).name;
        }
        res.send(members);
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})


router.route('/viewStaffinDepartmentByCourse')
.post(hodAuth,async(req, res)=>{//view staff in my department
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const body=req.body;
        await hodJoi.viewStaff.validateAsync(body);
        const dep=await departmentModel.findOne({"_id":member.department});
        const courseName=body.courseName;
        const course= await courseModel.findOne({"name": courseName});  
        if(!course)
            return res.status(400).json({err:"course is not found"});
        const courseId=course.id;

            let print=[];
            let members =await staffModel.find({"department":member.department});
            members.forEach(async(value1)=>{
                let findCourse="false"
                let coursesIds= value1.coursesIds;
                coursesIds.forEach((value2)=>{
                  if(value2.courseId==courseId)
                      findCourse="true"
                });        
                if(findCourse=="true"){
                    value1.password='XXXXXXXXXXX'
                    value1.department=dep.name;
                    // if(value1.officeLocation!='N/A'){
                    //        valu1.officeLocation=(await locationModel.findOne({"_id":value1.officeLocation})).name;
                    // }
                    print.push(value1);
                }
            }
            );
            res.send(print);
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})


router.route('/viewDayOffAllStaff')
.get(hodAuth,async(req, res)=>{//view the dayOff for all staff
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        let members =await staffModel.find({"department":member.department});
         let print=[];
        members.forEach(getDayOff);
       async function getDayOff(value){
        print.push({"id":value.id,"name":value.name,"dayOff":value.dayOff});
       }
       res.send(print);
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/viewDayOffSingleStaff')
.get(hodAuth,async(req, res)=>{//view the dayOff for one staff member
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const body=req.body
        await hodJoi.viewDaysOff.validateAsync(body);
        const staffId=body.id;
        const member= await staffModel.findOne({"id": verified.id});
        const staffMember =await staffModel.findOne({"id":staffId});
        if(staffMember!=null){
            if(staffMember.department!=member.department)
            return res.status(500).json({err:"this person is not in this department"}); 
        res.send({"id":staffMember.id,"name":staffMember.name,"dayOff":staffMember.dayOff});
        }
        else
        res.status(500).json({err:"person not found"}); 
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/viewDayOffRequests')//to be tested
.get(hodAuth,async(req, res)=>{//view all the dayOff requests sent by people in the department
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        let requests =await ChangeDayOffModel.find({"department":member.department});

        requests.forEach(async(value)=>{
                 value.SeenReceiver=true;
                 await value.save();
        })
        
 
        res.send(requests);
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})


router.route('/viewLeaveRequests')//to be tested
.get(hodAuth,async(req, res)=>{//view all the Leave requests sent by people in the department
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        let requests =await LeaveRequestModel.find({"department":member.department});

        requests.forEach(async(value)=>{
         value.SeenReceiver=true;
         await value.save();
        })
        
        res.send(requests); 
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/handleDayOffRequests')//to be tested
.put(hodAuth,async(req, res)=>{//handle dayOff request be approving or rejecting
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const body=req.body;
        await hodJoi.handleDayOff.validateAsync(body);
        const requestId= body.requestId;
        const state =body.state;
        const request =await ChangeDayOffModel.findOne({"_id":requestId});
        if(request==null)
            return res.status(400).json({err:"no such changeDayOff request"});
        if(request.department!=member.department)
            return  res.status(400).json({err:"the request is not in this department"});
        request.SeenSender=false;
        if(state=='accepted'){
            request.status="accepted";
            res.status(200).json({msg:"request approved"});
        }
        else{
            request.status="rejected";
            res.status(200).json({msg:"request denied"});
        }
        await request.save();
        await member.save();
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/handleLeaveRequests')//tbt
.put(hodAuth,async(req, res)=>{//handle leave request be approving or rejecting
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const body=req.body;
        await hodJoi.leaveRequset.validateAsync(body);
        const requestId= body.requestId;
        const state =body.state;
        const request =await LeaveRequestModel.findOne({"_id":requestId});
        if(request==null)
            return res.status(400).json({err:"no such leave request"});
        if(request.department!=member.department)
            return  res.status(400).json({err:"the request is not in this department"});
        request.SeenSender=false;
        if(state=='accepted'){
            request.status="accepted";
            res.status(200).json({msg:"request approved"});
        }
        else{
            request.status="rejected";
            res.status(200).json({msg:"request denied"});
        }
        await request.save()
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})


router.route('/handleReplacementRequest')//tbt
.put(hodAuth,async(req, res)=>{//handle leave request be approving or rejecting
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const body=req.body;
        await hodJoi.leaveRequset.validateAsync(body);
        const requestId= body.requestId;
        const state =body.state;
        const request =await LeaveRequestModel.findOne({"_id":requestId});
        if(request==null)
            return res.status(400).json({err:"no such leave request"});
        if(request.department!=member.department)
            return  res.status(400).json({err:"the request is not in this department"});
        request.SeenSender=false;
        if(state=='accepted'){
            request.status="accepted";
            res.status(200).json({msg:"request approved"});
        }
        else{
            request.status="rejected";
            res.status(200).json({msg:"request denied"});
        }
        await request.save()
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/viewCourseCoverage')//tbt
.get(hodAuth,async(req, res)=>{//view a course coverage in the department
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const body=req.body;
        await hodJoi.courseCoverage.validateAsync(body);
        const courseName =body.courseName;
        const course =await courseModel.findOne({"name":courseName});
      if(!course)
        return res.status(400).json({err:"there is no such course"});
      if(course.mainDepartment!=member.department)
        return res.status(400).json({err:"the course is in different department form the HOD"});
      res.send({"name":course.name,"code":course.code,"coverage":course.coverage});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

router.route('/viewTeachingAssignments')
.post(hodAuth,async(req, res)=>{//view which staff members teach which slots of some course in the department
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const body=req.body
        await hodJoi.teachingAssignments.validateAsync(body); 
        const courseName=body.courseName;
        const member= await staffModel.findOne({"id": verified.id});
        const course=await courseModel.findOne({"name": courseName});
        if(course==null){
          return  res.status(400).json({err:"no such course"});
        }
        if(member.department!=course.mainDepartment){
            return  res.status(400).json({err:"course department is not the same department as HOD"});
        }

        let staffMembers=await staffModel.find({"department": member.department});

        let print=[]
         const courseId=course.id;
       staffMembers.forEach((value1)=>{
        let coursesIds=value1.coursesIds;
        let checkCourse="false";
        coursesIds.forEach((value2)=>{
            if(value2.courseId==courseId)
                checkCourse="true"
          }        );

        if(checkCourse=="true"){
            let schedule=value1.schedule;
            let slotsForCourse=[]
            schedule.forEach((value3)=>{
                if(value3.course==courseId)
                   slotsForCourse.push({"Day":value3.day,"slot":value3.slot,"location":value3.location})
                })
            
            print.push({"id":value1.id,"name":value1.name,"slotsForTheCourse":slotsForCourse});
        } 
       })
        
     res.send(print);
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})



module.exports= router