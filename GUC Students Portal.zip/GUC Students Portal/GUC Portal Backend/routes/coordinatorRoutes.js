const express= require('express');
const router= express.Router()
//models needed

//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken')

const blackListedTokens = require('../models/TokenBlackList')

const staffModel= require('../models/staff');
const courseModel= require('../models/Course');
const slotLinkingModel = require('../models/SlotLinking');
const locationModel = require('../models/location');
const coordJoi=require('../joiRoutesSchemes/coordinatorJoi')

//auth
const coAuth=async (req,res,next)=>{
    try{    
        const token=req.header("token");//header in log in post request (postman)
        const isValidToken = await blackListedTokens.findOne({jwt : token})
        if(isValidToken){
            return res.status(401).json({msg:"Not signed in"});
        }
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const role=member.role;
        if(role=='coordinator')next();
        else return res.status(401).json({err:"No access rights"});
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
}

//routes start here
router.route('/viewSlotRequests')
.get(coAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id = member.id;
        
        const coordinatedCourses = await courseModel.find({coordinatorId: id});
        const result = [];
        for (var i=0; i<coordinatedCourses.length; i++){
            const curCrsId= coordinatedCourses[i].id;
          //  console.log(curCrsId);
            const curReqs = await slotLinkingModel.find({courseId:curCrsId});
            result.push(...curReqs);
        }
        if(result.length!=0){
            for(let i=0;i<result.length;i++){
            const cou=await courseModel.findOne({_id:result[i].courseId})
            const loc=await locationModel.findOne({_id:result[i].location})
            result[i].courseId=cou.code
            result[i].location=loc.name
            await slotLinkingModel.updateOne({_id:result[i]._id},{SeenReceiver:true})
            }
        }    
        return res.status(200).json(result);
    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})

router.route('/acceptSlotRequest')
.put(coAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id = member.id;
        
        const reqId = req.body.reqId;
        const reqDoc = await slotLinkingModel.findOne({_id:reqId});
        if(!reqDoc){
            return res.status(406).json({err:'No request with this id'});
        }
        if(reqDoc.status!='pending'){
            return res.status(406).json({err:"The request has been handled previously!"})
        }
        const crsDoc = await courseModel.findOne({_id:reqDoc.courseId});
        // if(!crsDoc){   }
        const crsCrd = crsDoc.coordinatorId;
        if (id != crsCrd){
            return res.status(401).json({err:"No access rights to handle this request! Probably you're no longer coordinator for this course"});
        }

        
        //notify ?
        const slotDay = reqDoc.day;
        const slotNum = reqDoc.slot;
        const slotLoc = reqDoc.location;

        const senderId = reqDoc.senderId;
        
        const crsSched = crsDoc.slots;
        const oldNumS = crsSched.length;
        const oldOccup = oldNumS * crsDoc.coverage;
        var crsSet = 0;
        for (var i=0; i<crsSched.length; i++){
            if (crsSched[i].day==slotDay && crsSched[i].slot==slotNum &&
                crsSched[i].location==slotLoc){
                if (crsSched[i].academic!='N/A'){
                    res.status(400).json({err:"This slot is already assigned to someone else"});
                }
                else{
                    crsSched[i].academic=senderId;
                    // let slotLoc = crsSched[i].location;
                    crsSet++;
                }
            }
        }
        if (!crsSet){
             res.status(400).json({err:"This slot isn't defined for this course"});
        }
        crsDoc.coverage = 100*((oldOccup+crsSet)/(crsDoc.slots.length));

        const senderDoc = await staffModel.findOne({id:senderId});
        console.log("here");
        const senderSched = senderDoc.schedule;
        console.log(senderDoc);
        var sltSet = false;
        for (var i=0; i<senderSched.length; i++){
            console.log("sndrschd",i,senderSched[i]);
            if (senderSched[i].day==slotDay && senderSched[i].slot==slotNum){
                if (senderSched[i].course!='N/A'){
                    return res.status(400).json({err:"This slot is already busy for another course"});
                }
                else{
                    senderSched[i].course=crsDoc.id;
                    senderSched[i].location =  slotLoc;
                    sltSet= true; 
                }
            }
        }
        if(!sltSet){
            senderSched.push({day:slotDay, slot:slotNum, location:slotLoc, course:crsDoc.id});
            sltSet=true;
        }
        if(crsSet && sltSet){
            reqDoc.status='accepted';
            await reqDoc.save();
            await crsDoc.save();
            await senderDoc.save();
            return res.status(200).json({msg:"Accepted Request !"});
        }
        else{
            return res.status(500).json({err:"Wrong slot in request"});
        }

    }
    catch(err){ 
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})

router.route('/rejectSlotRequest')
.put(coAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id = member.id;
        
        const reqId = req.body.reqId;
        const reqDoc = await slotLinkingModel.findOne({_id:reqId});
        if(!reqDoc){
            res.status(406).json({err:'No request with this id'});
        }
        if(reqDoc.status!='pending'){
            return res.status(406).json({err:"The request has been handled previously!"})
        }
        const crsDoc = await courseModel.findOne({_id:reqDoc.courseId});
        // if(!crsDoc){   }
        const crsCrd = crsDoc.coordinatorId;
        // console.log(id,crsCrd);
        if (id != crsCrd){
            res.status(401).json({err:"No access rights to handle this request! Probably you're no longer coordinator for this course"});
        }

        reqDoc.status='rejected';
        await reqDoc.save();
        res.status(200).json({msg:'Successfully rejected request!'});

    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})

router.route('/courseSlot')
.post(coAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id = verified.id;
        
        await coordJoi.postCourseSlot.validateAsync(req.body);
        const crsCode = req.body.course;
        const crsDoc = await courseModel.findOne({code:crsCode});
        // if(!crsDoc){   }
        const crsCrd = crsDoc.coordinatorId;
        if (id != crsCrd){
            return res.status(401).json({err:"No access rights to handle this request! Probably you're no longer coordinator for this course"});
        }

        const slotDay = req.body.day;
        const slotNum = req.body.slot;
    
        const slotLoc = req.body.location;
        if(slotLoc==='' || slotLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }

        const slotLocDoc = await locationModel.findOne({name:slotLoc});
        if (!slotLocDoc){
            //slotLoc = 'N/A';
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        if(slotLocDoc.type=='office'){
            //  return res.status(406).send("cannot assign a slot in an office");
              return res.status(406).json({err:"cannot assign a slot in an office"})
        }
        const slotLocId = slotLocDoc.id;

        const courseSlots = crsDoc.slots;
        for (var i=0;i<courseSlots.length;i++){
            if(courseSlots[i].day==slotDay &&courseSlots[i].slot==slotNum 
                && courseSlots[i].location==slotLocId){
                    return res.status(406).json({err:"There is already a slot for this course in the same timing and location"})
                }
        }
        courseSlots.push({day:slotDay, slot:slotNum, location:slotLocId, academic:'N/A'});
        await crsDoc.save();
        res.status(200).json({msg:"Sucessfully added the slot!"});
    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})
.put(coAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id = verified.id;

        await coordJoi.putCourseSlot.validateAsync(req.body);

        const crsCode = req.body.keyCourse;
        const crsDoc = await courseModel.findOne({code:crsCode});
        const crsCrd = crsDoc.coordinatorId;
        if (id != crsCrd){
            res.status(401).json({err:"No access rights to handle this request! Probably you're no longer coordinator for this course"});
        }

        const slotDay = req.body.keyDay;
        const slotNum = req.body.keySlot;
        const oldLoc = req.body.keyLoc;
        if(oldLoc==='' || oldLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }
        const oldLocDoc = await locationModel.findOne({name:oldLoc});
        if (!oldLocDoc){
            //slotLoc = 'N/A';
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        const oldLocId = oldLocDoc.id;

        const courseSlots = crsDoc.slots;

        const newLoc = req.body.newLoc;
        if(newLoc==='' || newLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }
        const newLocDoc = await locationModel.findOne({name:newLoc});
        if (!newLocDoc){
            //slotLoc = 'N/A';
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        if(newLocDoc.type=='office'){
            //  return res.status(406).send("cannot assign a slot in an office");
              return res.status(406).json({err:"cannot assign a slot in an office"})
        }
        const newLocId = newLocDoc.id;
        const updStf = [];
        var hitCnt = 0;
        for (var i=0;i<courseSlots.length;i++){
            if(courseSlots[i].day==slotDay &&courseSlots[i].slot==slotNum 
                && courseSlots[i].location==oldLocId){
                    // console.log("here");
                    courseSlots[i].location=newLocId;
                    hitCnt++;
                    if(courseSlots[i].academic!="N/A"){
                        updStf.push(courseSlots[i].academic);
                    }
                }
        }
        for (var j=0;j<updStf.length;j++){
            const uDoc = await staffModel.findOne({id:updStf[j]});
            const uSch = uDoc.schedule;
            var hts = 0;
            for (var i=0;i<uSch.length;i++){
                if(uSch[i].day==slotDay && uSch[i].slot==slotNum &&
                    uSch[i].location==oldLocId && uSch[i].course==crsDoc.id){
                        uSch[i].splice(i,1);
                        i--;
                        hts++;
                    }
            }
            if(hts){
                await uDoc.save();
            }
        }
        if(hitCnt){
            await crsDoc.save();
            return res.status(200).json({err:"Successfully updated slot"});
        }
        else{
            return res.status(200).json({err:"Didn't found matches to update"});
            //TODO : What status code?
        }

    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})
.delete(coAuth, async(req, res)=>{
    try{
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const id = verified.id;

        await coordJoi.deleteCourseSlot.validateAsync(req.body);

        const crsCode = req.body.keyCourse;
        const crsDoc = await courseModel.findOne({code:crsCode});
        const crsCrd = crsDoc.coordinatorId;
        if (id != crsCrd){
            return res.status(401).json({err:"No access rights to handle this request! Probably you're no longer coordinator for this course"});
        }

        const slotDay = req.body.keyDay;
        const slotNum = req.body.keySlot;
        const slotLoc = req.body.keyLoc;
        if(slotLoc==='' || slotLoc=='N/A'){
            return res.status(406).json({err:"This is not a valid location"});
        }
        const slotLocDoc = await locationModel.findOne({name:slotLoc});
        if (!slotLocDoc){
            return res.status(406).json({err:"The location entered doesn't exist"});
        }
        const slotLocId = slotLocDoc.id;

        var hitCnt = 0;
        const delStf = []
        const courseSlots = crsDoc.slots;
        for (var i=0;i<courseSlots.length;i++){
            if(courseSlots[i].day==slotDay &&courseSlots[i].slot==slotNum 
                && courseSlots[i].location==slotLocId){
                    hitCnt++;
                    if (courseSlots[i].academic!="N/A"){
                        delStf.push(courseSlots[i].academic);
                    }
                    courseSlots.splice(i,1);
                    i--;
                }
        }
        
        for (var j=0;j<delStf.length;j++){
            const dDoc = await staffModel.findOne({id:delStf[j]});
            const sch = dDoc.schedule;
            var dlcnt =0;
            for (var i=0; i<sch.length;i++){
                if (sch[i].day==day && sch[i].slot==slotNum &&
                    sch[i].location==slotLoc &&sch[i].course==crsDoc.id){
                    sch.splice(i,1);
                    i--;
                    dlcnt++;
                }
            }
            if(dlcnt){
                await delStf[j].save();
            }
        }
        if(hitCnt){
            await crsDoc.save();
            return res.status(200).json({msg:"Successfully deleted slot"});
        }
        else{
            return res.status(200).json({err:"Didn't found matches to delete"});
            //TODO : What status code?
        }

        // var sltFnd = false;
        // const courseSlots = crsDoc.slots;
        // for (var i=0; i<courseSlots.length; i++){
        //     if (courseSlots[i].day==slotDay && courseSlots[i].slot==slotNum){ //may add location
        //         var slotAcad = courseSlots[i].academic
        //         courseSlots.splice(i,1);
        //         i--;
        //         sltFnd = true;
        //         break;
        //     }
        // }
        // if(!sltFnd){
        //     res.status(400).send("No such a slot exists");
        // }
        // console.log(slotAcad);
        // if(slotAcad!='N/A'){
        //     stfExs = tr
        //     const staff = await staffModel.findOne({id:slotAcad});
        //     const staffSched = staff.schedule;
        //     // sltFnd = false;
        //     for (var i=0; i<staffSched.length;i++){
        //         if (staffSched[i].day==slotDay && staffSched[i].slot==slotNum){
        //             if (staffSched[i].course==courseDoc._id){
        //                 staffSched.splice(i,1);
        //                 i--;
        //                 break;
        //                 // sltFnd = true;
        //             }
        //         }
        //     }   
        //     await staff.save();
        // }
        // //no need for sltFnd
        // if (!sltFnd){
        //     res.status(400).send("This slot doesn't exist");
        // }
        // else{
        //     await crsDoc.save();
        //     // await staff.save();
        //     res.send("Succsessfully removed this slot!");
        // }



    }
    catch(err){
        // console.log(err);
        return res.status(500).json({err:err.message});
    }

})


module.exports= router