const express= require('express');
const router= express.Router()
//models needed
const locationModel= require('../models/location')
const facultyModel= require('../models/Faculty')
const courseModel= require('../models/Course');
const departmentModel= require('../models/Department');
const staffModel= require('../models/staff');
const leaveRequestModel=require('../models/LeaveRequest');
const replacementRequestModel=require('../models/ReplacementRequest');
const slotLinkingRequestModel=require('../models/SlotLinking');
const changeDayoffRequestModel=require('../models/ChangeDayOff');
//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken')
const staffJoi=require('../joiRoutesSchemes/staffJoi')
//routes start here
router.route('/login')                               //TODO check if the pass = 123456 without decrypting to know if its the first time
.post(async (req,res)=> {
    try {
        const email = req.body.email;
        const password = req.body.password;
        const newPassword = req.body.newPassword;
      //  console.log(staffJoi)
        if(!email||!password){
            return res.status(400).json({msg:"Empty email/password"});
        }
        const member = await staffModel.findOne({"email": email})
        if(!member){
            return res.status(400).json({msg:"Non existing member"});
        }
        let correctPass;
        if(member.password =='123456'){
            if(password != '123456'){
                return res.status(400).json({msg:"Wrong password"});
            }
            if(!newPassword){
                return res.status(400).json({msg:"Must enter a new password on your first login"});
            }
            await staffJoi.signInNewPassJoi.validateAsync({newPassword : newPassword}); 
            const salt = await bcrypt.genSalt();
            const passHashed = await bcrypt.hash(newPassword,salt);
            correctPass = true;
            await staffModel.updateOne({id : member.id},{password : passHashed})
        }
        else{
            correctPass = await bcrypt.compare(password, member.password)
        }
        if(correctPass){
            const token = jwt.sign({
                email : email,
                id : member.id,
                name : member.name,
                role : member.role
            }, process.env.tokenSecret)
            res.header('token',token).send(token) 
        }else{
            return res.status(400).json({msg:"Wrong password"});
        }   
    }
    catch (err){
        
        return res.status(500).json({err:err.message});
    }
})

//adding seeds
router.route('/seed')
.post(async (req,res) => {
    try{
        const num=await staffModel.findOne({"id":"hr-1"})
        if(num != null)
            return res.status(401).json({msg:"First Member Already exists"});
        let body = req.body;
        // generating salt of 2^10
        const loc=new locationModel({
            name : "C3.310", type: "office", curCapacity: 0, maxCapacity:20
           })
           await loc.save();
        const faculty= new facultyModel({
            name:"Engineering",
            code:"ENG" 
        })
        await faculty.save();
        const fac=await facultyModel.findOne({code:"ENG"})
        const dep=new departmentModel({
            name:"Media Engineering and Technology",
            code:"MET",//shorthand for department
            facultyId:fac.id,
            headOfDepartmentId:"N/A",
            coursesIds:[]
        })
        await dep.save();
        const dp=await departmentModel.findOne({code:"MET"})
        const newPassword ="123456";
        const newHr = new staffModel({
            id : "hr-1",
            email :"abdul@gmail.com",
            name : "Abdullah",
            password : newPassword,
            salary :10000,
            gender :"male",
            officeLocation :"C3.310",
            role: "HR",
            signInLogs : [],
            dayOff : "Saturday",
            coursesIds : [],
            schedule : [],
            department :  "N/A"
        })
        await newHr.save();

        const newAc = new staffModel({
            id : "ac-1",
            email :"omar@gmail.com",
            name : "Omar",
            password : newPassword,
            salary :10000,
            gender :"male",
            officeLocation :"C3.310",
            role: "HOD",
            signInLogs : [],
            dayOff : "Monday",
            coursesIds : [],
            schedule : [],
            department :  dp.id
        })
        await newAc.save();
        dep.headOfDepartmentId="ac-1"
        await dep.save()
        res.status(200).json({msg:"Database seeded"});
   
    }
    catch (err){
        return res.status(500).json({err:err.message});
    }
    
})
module.exports=router;