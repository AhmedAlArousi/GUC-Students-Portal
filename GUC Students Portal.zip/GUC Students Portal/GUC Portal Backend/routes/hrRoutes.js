//TODO cascading deletions upon deleting a faculty/department/courses
const express= require('express');
const router= express.Router()
//models needed
const locationModel= require('../models/location')
const facultyModel= require('../models/Faculty')
const courseModel= require('../models/Course');
const departmentModel= require('../models/Department');
const staffModel= require('../models/staff');
const leaveRequestModel=require('../models/LeaveRequest');
const replacementRequestModel=require('../models/ReplacementRequest');
const slotLinkingRequestModel=require('../models/SlotLinking');
const changeDayoffRequestModel=require('../models/ChangeDayOff');
//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken');
const blackListedTokens = require('../models/TokenBlackList')
const { deleteOne, off, update } = require('../models/location');
//require functs
const viewMissing=require('../Functions/staffFuncts');
//require joi
const Joi = require('joi');
const hrJoi=require('../joiRoutesSchemes/hrJoi')
//auth
const hrAuth=async (req,res,next)=>{
    try{    
        const token=req.header("token");//header in log in post request (postman)
        const isValidToken = await blackListedTokens.findOne({jwt : token})
        if(isValidToken){
            return res.status(401).json({msg:"Not signed in"});
        }
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const role=member.role;
         if(role=='HR')
            next();
         else 
            return res.status(401).json({err:"No access rights"});
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
}

//routes start here

//location altering

router.route('/location')
.get(hrAuth,async(req, res)=>{
    try{
        const result=await locationModel.find({});
      //  console.log(result)
        res.send(result)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
.post(hrAuth,async(req, res)=>{//T
    try{
        const  body=req.body;
        await hrJoi.postLocation.validateAsync(body);
        if(body.type=='Office'){//if cur not provided,make a default 0
            if(!body.curCapacity)
                req.body.curCapacity=0;
            else if(body.curCapacity>body.maxCapacity)
                return res.status(400).json({err:"curCapacity more than maxCapacity"});
            

         }
        if(body.type!='Office'&&body.curCapacity){
             return res.status(400).json({err:"This location type has no curCapacity"});
         }
        const result= await locationModel(req.body).save()
        res.status(200).json({msg:"Added successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.delete(hrAuth,async(req,res)=>{//deleting from offices/schedules (test the schedules)
    try{
        await hrJoi.stringId.validateAsync(req.body.name);
        const name=req.body.name;
        const entry= await locationModel.findOne({name:name});
        if(!entry){
            return res.status(400).json({err:"The location doesn't exist already"});
        }
        //delete assigned offices
        if(entry.type=='Office')
            await staffModel.updateMany({officeLocation:entry.id},{officeLocation:"N/A"})
        else{
            //remove from all schedules
            let staffs=await staffModel.find({});
            let courses=await courseModel.find({});
        for(let c=0;c<staffs.length;c++){
            for(let i=0;i<staffs[c].schedule.length;i++){
                if(staffs[c].schedule[i].location==entry.id){
                    staffs[c].schedule[i].location="N/A";

                }
            }
            await staffs[c].save()
        }
        for(let c=0;c<courses.length;c++){
            for(let i=0;i< courses[c].slots.length;i++){
                if( courses[c].slots[i].location==entry.id){
                    courses[c].slots[i].location="N/A";
                }
            }
            await courses[c].save()
        }
        }
        
        await locationModel.deleteOne({name:name});
        res.status(200).json({msg:"Deleted successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.put(hrAuth,async(req,res)=>{ //T
    try{
        await hrJoi.putLocation.validateAsync(req.body);
        const key=req.body.key;
        //retrieve
        const entry=await locationModel.findOne({name:key})
        const locations=await locationModel.find({});
        if(!entry){
            return res.status(400).json({err:"Location doesn't exist"});
        }
        const curCapacity=req.body.curCapacity;
        //form the new vals
        if(entry.type!='Office'&&curCapacity){
            return res.status(400).json({err:"This location cannot have a current capacity"});
        }
        for(let i=0;i<locations.length;i++){
                    if(locations[i].name==req.body.name)
                      return res.status(400).json({err:"This location already exists"});
        }
       // delete req.body.key
        const newEntry = await locationModel.updateOne({ name: key },req.body);
        res.status(200).json({msg:"Updated successfully"});

     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

//faculty
router.route('/faculty')
.get(hrAuth,async(req, res)=>{
    try{
        const result=await facultyModel.find({});
      //  console.log(result)
        res.send(result)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
.post(hrAuth,async(req, res)=>{//T
    try{
        await hrJoi.postFaculty.validateAsync(req.body);
        const result= await facultyModel(req.body).save()
        res.status(200).json({msg:"Added successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.delete(hrAuth,async(req,res)=>{ //T
    try{
       // await hrJoi.stringId.validateAsync(req.body.code);
        const code=req.body.code;
        const entry= await facultyModel.findOne({code:code});
        if(!entry){
            return res.status(400).json({err:"The Faculty doesn't exist already"});
        }
        await facultyModel.deleteOne({code:code});
        const fcid=entry.id;
        await departmentModel.updateMany({facultyId:fcid},{facultyId:"N/A"})
        res.status(200).json({msg:"Deleted successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.put(hrAuth,async(req,res)=>{
    try{
        // T
        await hrJoi.putFaculty.validateAsync(req.body);
        const key=req.body.key;
        //retrieve
        const entry=await facultyModel.findOne({code:key})
        if(!entry){
            return res.status(400).json({err:"Faculty doesn't exist"});
        }
        const newEntry = await facultyModel.updateOne({ code: key },req.body);
        res.status(200).json({msg:"Updated successfully"});

     }catch(err){
         return res.status(500).json({err:err.message});
     }
})

//department

router.route('/department')
.get(hrAuth,async(req, res)=>{
    try{
        let result=await departmentModel.find({});
        //console.log(result)
        for(let i=0;i<result.length;i++){
            let faculty='N/A';
            let head='N/A';
            if(result[i].facultyId!='N/A'){
                let f =await facultyModel.findOne({_id:result[i].facultyId});
               // console.log(f)
                faculty=f.code;
            }
            if(result[i].headOfDepartmentId!='N/A'){
                let h=await staffModel.findOne({id:result[i].headOfDepartmentId});
               // console.log(h)
                head=h.id;
               // console.log(head)
            }
           // console.log(faculty)
            //console.log(head)
            result[i]={...result[i],faculty,head};
           // result[i]={...result[i],faculty};
        }
        //console.log(result)
        res.send(result)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
.post(hrAuth,async(req, res)=>{//hod is assigned here
    try{
        await hrJoi.postDepartment.validateAsync(req.body);
        const fac=await facultyModel.findOne({code:req.body.facCode});
        if(!fac){
            return res.status(400).json({err:"Faculty doesn't exist"});
        }
        req.body.facultyId=fac.id;
        const findStaff=await staffModel.findOne({id:req.body.headOfDepartmentId})
        req.body.headOfDepartmentId="N/A";
        req.body.coursesIds=[];
        delete req.body.facCode;

        const result= await departmentModel(req.body).save()
        res.status(200).json({msg:"Added successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.delete(hrAuth,async(req,res)=>{
    try{
        await hrJoi.stringId.validateAsync(req.body.code);
        const code=req.body.code;
        const entry= await departmentModel.findOne({code:code});
        if(!entry){
            return res.status(400).json({err:"The Department doesn't exist already"});
        }
        const hod=entry.headOfDepartmentId;
        if(hod!="N/A"){//IMPORTANT TO TEST PLEASE
            await staffModel.updateOne({id:hod},{role:'instructor'});
        }
        await departmentModel.deleteOne({code:code});
        //make staff's dep N/A
        await staffModel.updateMany({department:entry.id},{department:"N/A"});
        let arr=entry.coursesIds;
        arr.forEach(async(id)=>{
            const course=await courseModel.findOne({_id:id});
            if(course.mainDepartment==entry.id){
                await courseModel.updateOne({_id:id},{mainDepartment:"N/A"});
            }
        })
        res.status(200).json({msg:"Deleted successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.put(hrAuth,async(req,res)=>{//hod is updated here
    try{
        await hrJoi.putDepartment.validateAsync(req.body);
        const key=req.body.key;
        //retrieve
        const entry=await departmentModel.findOne({code:key})
        if(!entry){
            return res.status(400).json({err:"Department doesn't exist"});
        }
        if(req.body.headOfDepartmentId){//change the hod
           const curHod=entry.headOfDepartmentId;
           const person=await staffModel.findOne({"id":req.body.headOfDepartmentId})
           if(person.department!='N/A'&&person.department!=entry.id){
            return res.status(400).json({err:"This person is not in this department"});
           }
           if(req.body.headOfDepartmentId!=entry.headOfDepartmentId){
                if(person.role!='instructor')
                    return res.status(400).json({err:"This person is not an instructor"});
                else{
                    await staffModel.updateOne({id:person.id},{role:'HOD'})
                    if(person.department=='N/A'){
                        await staffModel.updateOne({id:person.id},{department:entry.id})

                    }
                }
                    
                if(curHod!='N/A')
                    await staffModel.updateOne({id:curHod},{role:'instructor'})
           }
        }
        //if hr can change faculty
        if(req.body.facCode){
            const fac=await facultyModel.findOne({code:req.body.facCode})
            if(fac)
              req.body.facultyId=fac.id;
            else
              return res.status(400).json({err:"Faculty doesn't exist"});
        }
        //form the new vals
        const newEntry = await departmentModel.updateOne({ code: key },req.body);
        res.status(200).json({msg:"Updated successfully"});

     }catch(err){
         return res.status(500).json({err:err.message});
     }
})


//course T
router.route('/course')
.get(hrAuth,async(req, res)=>{
    let result=await courseModel.find({});
    let deps=await departmentModel.find({});
    for(let i=0;i<result.length;i++){
        let department=result[i].mainDepartment;
        if(result[i].mainDepartment!='N/A'){
            let x= await departmentModel.findOne({_id:result[i].mainDepartment});
            department=x.code;
        }
        result[i].mainDepartment=department;
        let cid=result[i].id;
        let mydeps=[];
        
        for(let j=0;j<deps.length;j++){

            for(let k=0;k<deps[j].coursesIds.length;k++){
                ///console.log(deps[j].coursesIds.courseId)
                if(deps[j].coursesIds[k].courseId==cid){
                    mydeps.push(deps[j].code);
                    break;
                }
            }
        }
        //console.log(mydeps)
        result[i]={...result[i],deps:mydeps}
    }
    //console.log(result)
    res.send(result);
})
.post(hrAuth,async(req, res)=>{//name,code and hod
    try{
        let course=await courseModel.findOne({code:req.body.code})
        if(!course){
            await hrJoi.postCourse.validateAsync(req.body);
        }
        
        const dep=await departmentModel.findOne({code:req.body.dep});
        if(!dep){
            return res.status(400).json({err:"Department doesn't exist"});
        }
        if(!course){
            req.body.coordinatorId="N/A";
            req.body.slots=[];
            req.body.coverage=0;
            req.body.mainDepartment=dep.id;
            await courseModel(req.body).save();
        }
        course=await courseModel.findOne({code:req.body.code})
        let arr=dep.coursesIds;
        arr.push({courseId:course.id});
        await departmentModel.updateOne({code:req.body.dep},{coursesIds:arr})//adding course to department array
        res.status(200).json({msg:"Added successfully"});

     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.delete(hrAuth,async(req,res)=>{//takes course and a department,course and dep code
    try{
        await hrJoi.deleteCourse.validateAsync(req.body);
        const codeC=req.body.codeCourse;
        const codeD=req.body.codeDepartment;
        const course= await courseModel.findOne({code:codeC});
        const dep=await departmentModel.findOne({code:codeD});
        if(!course||!dep){
            return res.status(400).json({err:"Department doesn't exist already"});
        }
        if(dep.id==course.mainDepartment)
            await courseModel.updateOne({code:codeC},{mainDepartment:"N/A"});
        let arr=dep.coursesIds.filter(cid=>cid.courseId!=course.id);
        await departmentModel.updateOne({code:codeD},{coursesIds:arr}); 
        res.status(200).json({msg:"Deleted successfully"});
     }catch(err){
         return res.status(500).json({err:err.message});
     }
     
})
.put(hrAuth,async(req,res)=>{//hod is updated here
    await hrJoi.putCourse.validateAsync(req.body);
    try{
        await hrJoi.putCourse.validateAsync(req.body)
        const key=req.body.key;
        //retrieve
        const entry=await courseModel.findOne({code:key})//by code
        if(!entry){
            return res.status(400).json({err:"No such course"});
        }
        const newEntry = await courseModel.updateOne({ code: key },req.body);
        res.status(200).json({msg:"Updated successfully"});

     }catch(err){
         return res.status(500).json({err:err.message});
     }
})



//member
router.route('/member')
.get(hrAuth ,async (req,res)=>{
    try{
        let result=await staffModel.find({});
        for(let i=0;i<result.length;i++){
            if(result[i].officeLocation!='N/A'){
                let office=await locationModel.findOne({_id:result[i].officeLocation});
                result[i].officeLocation=office.name;
            }
            if(result[i].department!='N/A'){
                let dep=await departmentModel.findOne({_id:result[i].department});
                result[i].department=dep.code;
            }
        }
        res.send(result);
     }catch(err){
         return res.status(500).json({err:err.message});
     }
})
.post(hrAuth ,async (req,res) => { //T
    try{
     await hrJoi.postMember.validateAsync(req.body);
    let body = req.body;
    const newPassword = "123456";
    const department=body.department;
    const dep=await departmentModel.findOne({code:department});
    const role=body.role;
    if(!dep&&role!='HR'){
        return res.status(400).json({err:"This department doesn't exist "});
    }
    
    if(role=='coordinator'){
        return res.status(400).json({err:"Instructor only can assign an academic to be a coordinator"});
    }
    //forming id
    let staff=await staffModel.find({});
    let id=''
    if(role=='HR'){
        staff=staff.filter((member)=>member.role=='HR');
        id+='hr-';
        if(req.body.department){
            return res.status(400).json({err:"HR has no department"});
        }
        if(body.dayOff!='Saturday'){
            return res.status(400).json({err:"HR cannot have dayoff other than saturday"});
        }
        //dep.id="N/A"
    }else{
        staff=staff.filter((member)=>member.role!='HR');
        id+='ac-';
    }
    let arr=[];

    staff.forEach((member)=>{
        let num=parseInt(member.id.substring(3));
        arr.push(num)
    })
    arr.sort((a,b)=>{
        return a-b;
    });
    if(arr.length>0){
        id+=(arr[arr.length-1]+1);
    }else{
        id+=1;
    }
    const office=body.officeLocation;
    const loc=await locationModel.findOne({name:office})
    if(!loc){
        return res.status(400).json({err:"non-existing location"});
    }
    if(loc.curCapacity==loc.maxCapacity){
        return res.status(400).json({err:"office full"});
    }
    if(loc.type!='Office'){
        return res.status(400).json({err:"this is not an office"});
    }
    //only one hod per department
    if(role=='HOD'&&req.body.department){
        dep.headOfDepartmentId=id;
        const hods=await staffModel.find({department:dep.id,role:'HOD'});
        if(hods.length!=0){
            return res.status(400).json({err:"there is an already assigned hod to this department"});
        }
    }
    body.officeLocation=loc.id;
    const depId=role=='HR'?"N/A":dep.id
    const newMem = new staffModel({
        id : id,
        email : body.email,
        name : body.name,
        password : newPassword,
        salary : body.salary,
        gender : body.gender,
        officeLocation : body.officeLocation,
        role: role,
        signInLogs : [],
        dayOff : body.dayOff,
        coursesIds : [],
        schedule : [],
        department :  depId
    })
    await newMem.save();
    if(role!='HR')
    await dep.save();
    await locationModel.updateOne({name:office},{curCapacity:loc.curCapacity+1})
    res.status(200).json({msg:"Added successfully"});

    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
})
.delete(hrAuth ,async (req,res) =>{//takes id
    try{
        await hrJoi.stringId.validateAsync(req.body.id);
        const id=req.body.id;
        const staff=await staffModel.findOne({id:id});
        if(!staff){
            return res.status(400).json({err:"Staff member doesn't exist already"});
        }
        const officeId=staff.officeLocation;
        if(officeId!='N/A'){
            const office=await locationModel.findOne({_id:officeId})
            await locationModel.updateOne({_id:officeId},{curCapacity:office.curCapacity-1})
        }
        Promise.all([
      
        //remove requests
        await replacementRequestModel.deleteMany({ $or: [{senderId: id}, {receiverId: id}] }),
        await slotLinkingRequestModel.deleteMany({senderId:id}),
        await changeDayoffRequestModel.deleteMany({senderId:id}),
        await leaveRequestModel.deleteMany({senderId:id})
        ])
        if(staff.role=='HOD'){
            await departmentModel.updateOne({_id:staff.department},{headOfDepartmentId:"N/A"})
        }
        else if(staff.role=='coordinator'){
            await courseModel.updateMany({coordinatorId:id},{coordinatorId:"N/A"})
        }
        if(staff.role!='HR'){
            //schedules
            //remove them from each course schedule ,where they teach
            let arr=staff.coursesIds;
            let promises=[]
            arr.forEach(async(courseI)=>{
                const cid=courseI.courseId;
                let course=await courseModel.findOne({_id:cid});
                let schedule=course.slots;
                for(let i=0;i<schedule.length;i++){
                    if(schedule[i].academic==id){
                        schedule[i].academic="N/A";
                    }
                }
                promises.push(await courseModel.updateOne({_id:cid},{slots:schedule}));
                
            })
            Promise.all(promises);
        }
        await staffModel.deleteOne({id:id});
        res.status(200).json({msg:"Deleted successfully"});

    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
.put(hrAuth,async(req,res)=>{//TEST BLEZ
    try{
        await hrJoi.putMember.validateAsync(req.body);
        const id=req.body.id;
        const staff=await staffModel.findOne({id:id});
        if(!staff){
            return res.status(400).json({err:'no staff member with that id'})
        }
        if(req.body.dayOff){
            if(req.body.dayOff!='Saturday'&&staff.role=='HR')
                 return res.status(400).json({err:'cannot change dayoff of an hr member'})
            const changeDayoffs=await changeDayoffRequestModel.find({senderId:id});
            if(changeDayoffs.length!=0){
                let request=changeDayoffs[changeDayoffs.length-1];//take most recent request
                if(request.newday!=req.body.dayOff){
                    return res.status(400).json({err:'cannot change dayoff,the new dayoff added does not match the requested one'})
                }

            }else{
                return res.status(400).json({err:'cannot change dayoff,there is no change dayoff request for that member'})
            }
        }
        let dep;
        if(req.body.department&&req.body.department!='N/A'){
            dep=await departmentModel.findOne({code:req.body.department});
        
             if(!dep)
                return res.status(400).json({err:'non existing department'})
             req.body.department=dep.id;
            
        }
        let location;
        if(req.body.officeLocation!='N/A'){
            //console.log('xx')
            location=await locationModel.findOne({name:req.body.officeLocation});
            if(req.body.officeLocation){
                
                if(!location){
                    return res.status(400).json({err:'not a location'})
                }
                if(location.type!='Office'){
                    return res.status(400).json({err:'not an office'})
                }
                if(location.curCapacity==location.maxCapacity){
                    return res.status(400).json({err:'full office'})
            }
        }
    }   
        //roles , take care
        if(req.body.role=='HOD'&&staff.role=='instructor'){
            if(req.body.department!='N/A'){
                let departmentId=staff.department;
                if(req.body.department){
                    departmentId=dep.id;
                }
                let newDep=await departmentModel.findOne({_id:departmentId});
                if(newDep.headOfDepartmentId!='N/A'){
                    return res.status(400).json({err:'that department already has a HOD'})
                }
                newDep.headOfDepartmentId=staff.id
                await newDep.save();
                await departmentModel.updateOne({_id:departmentId},{headOfDepartmentId:staff.id})
        }
        }else if(req.body.role=='instructor'&&staff.role=='HOD'){
            if(req.body.department!='N/A'){
                if(staff.department!='N/A'){
                    await departmentModel.updateOne({_id:staff.department},{headOfDepartmentId:"N/A"});

                }
            }
    
        }
        else if(req.body.role=='HOD'&&staff.role=='HOD'){
            if(req.body.department&&req.body.department!='N/A'){
                if(staff.department!='N/A')
                    await departmentModel.updateOne({_id:staff.department},{headOfDepartmentId:'N/A'})
                await departmentModel.updateOne({_id:req.body.department},{headOfDepartmentId:staff.id})
            }
        }else if(req.body.role!=staff.role){
            if(req.body.role)
               return res.status(400).json({err:'not authorized to change these roles,only from instructor to hod'})
            if(staff.role=='HOD' && req.body.department!=null){
               let newDep=await departmentModel.findOne({_id:dep.id});
               if(newDep.headOfDepartmentId!='N/A'){
                return res.status(400).json({err:'that department already has a HOD'})
               }
               newDep.headOfDepartmentId=staff.id
               let oldDep=await departmentModel.findOne({_id:staff.department});
               oldDep.headOfDepartmentId='N/A'
               await oldDep.save();
               await newDep.save();
            }
        }

        
        //old and new office changing
        if(req.body.officeLocation&&req.body.officeLocation!='N/A'){
            const oldLocId=staff.officeLocation;
            if(oldLocId!='N/A'){
                const oldLoc=await locationModel.findOne({_id:oldLocId});
                // if(oldLoc.name==location.name){
                //     return res.status(200).json({msg:'it is the same office'})
                // }
                await locationModel.updateOne({_id:oldLocId},{curCapacity:oldLoc.curCapacity-1});
            }
            await locationModel.updateOne({name:req.body.officeLocation},{curCapacity:location.curCapacity+1})
            //can only change an instructor to hod,in case department has no hod
            req.body.officeLocation=location.id
        }
        await staffModel.updateOne({id:req.body.id},req.body)
        res.status(200).json({msg:"Updated successfully"});
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
//add sign record
router.route('/addSignRec').post(hrAuth ,async (req,res)=>{//takes id of staff,date and type of record (in or out)
    try{
        await hrJoi.postRecord.validateAsync(req.body);
        //await hrJoi.postRecord.validateAsync(req.body)
        const token=req.header("token");//header in log in post request (postman)
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        if(req.body.id==member.id){
            return res.status(400).json({err:'You cannot change your own sign in or out records'})
        }
        const id=req.body.id;
        //delete req.body.id;
        const staff=await staffModel.findOne({id:id});
        let arr=staff.signInLogs;
        let date=new Date(req.body.timeStamp);
        let day = date.getDay();
        if(day == 5){
            return res.status(400).json({err:'You cannot add sign in log on friday(ya nasab)'})
        }
        

        let hr=date.getUTCHours(),min=date.getUTCMinutes(),sec=date.getUTCSeconds();;
        if(hr<7&&req.body.type=='out'||(hr>19||hr==19&&min>0)&&req.body.type=='in'){
            return res.status(400).json({err:'neglected log'})
        }
        if(hr<7&&req.body.type=='in'){
            date.setUTCHours(7);
            date.setUTCMinutes(0);
            date.setUTCSeconds(0);
        }else if((hr>19||hr==19&&min>0)&&req.body.type=='out'){
            date.setUTCHours(19);
            date.setUTCMinutes(0);
            date.setUTCSeconds(0);
        }
        req.body.timeStamp=date.toString();
        arr.push(req.body)
        await staffModel.updateOne({id:id},{signInLogs:arr});
        res.status(200).json({msg:"Added successfully"});
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
})
//view atttendance
router.route('/viewAttendanceStaff').post(hrAuth ,async (req,res)=>{//T
    try{
        await hrJoi.stringId.validateAsync(req.body.id);
        const id=req.body.id;
        const staff=await staffModel.findOne({id:id});
        if(!staff){
            return res.status(400).json({err:'non existing staff'})
        }
        let arr=staff.signInLogs;
        arr.sort((a,b)=>{
            // Turn your strings into dates, and then subtract them
            // to get a value that is either negative, positive, or zero.
            return new Date(b.timeStamp) - new Date(a.timeStamp);
        });
        let index = 0;
        let result = [];
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        for (log of arr){
            let seconds = log.timeStamp.getSeconds();
            let minutes = log.timeStamp.getMinutes();
            let hour = log.timeStamp.getUTCHours();
            let x = hour >= 12 ? 'PM' : 'AM'
            let xy = hour < 10 ? '0' : '';
            let y = minutes < 10 ? '0' : '';
            let yx = seconds < 10 ? '0' : '';
            let time = xy + hour + ":" + y + minutes +':' + yx + seconds + " " + x;
            result.push({
            id : index,
            Type : log.type,
            DayName : days[log.timeStamp.getDay()] + " " + log.timeStamp.getDate(),
            Month : monthNames[log.timeStamp.getMonth()],
            YearNo : log.timeStamp.getFullYear(),
            Time : time, 
            })
            index++;
        }
        res.send(result);
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
})

router.route('/showMissingDaysHr')
.post(hrAuth,async(req,res)=>{
    try{
        await hrJoi.stringId.validateAsync(req.body.id);
        const staff=await staffModel.findOne({id:req.body.id});
        if(!staff){
            return res.status(400).json({err:'non existing staff'})
        }
        const x=await viewMissing.viewMissingDays(staff);
        const obj={days:x.length,dates:x}
        res.send(obj);
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
router.route('/showMissingHoursHr')
.post(hrAuth,async(req,res)=>{

    try{
        await hrJoi.stringId.validateAsync(req.body.id);
        const staff=await staffModel.findOne({id:req.body.id});
        if(!staff){
            return res.status(400).json({err:'non existing staff'})
        }
        const x=await viewMissing.viewMissingHours(staff);
        x.missingHours=x.missingHours.toFixed(3);
        x.extraHours=x.extraHours.toFixed(3);
        res.send(x);
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
router.route('/updateSalary')
.put(hrAuth,async(req,res)=>{
    try{
        await hrJoi.putSalary.validateAsync(req.body);
        if(! await staffModel.findOne({id:req.body.id})){
            return res.status(400).json({err:'non existing staff member'})
        }
        await staffModel.updateOne({id:req.body.id},{salary:req.body.salary});
        res.status(200).json({msg:"Updated successfully"});
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
module.exports= router