
const express= require('express');
const router= express.Router()
//models needed
const staffModel= require('../models/staff');
const replacementRequest=require('../models/ReplacementRequest')
const slotLinking=require('../models/SlotLinking')
const course=require('../models/Course')
const Department=require('../models/Department')
//const facultyModel=require('../models/Faculty')
const ChangeDayOff = require('../models/ChangeDayOff');
const LeaveRequest=require('../models/LeaveRequest')
const viewMissing=require('../Functions/staffFuncts');
const Location=require('../models/location')
//security
const bcrypt = require('bcrypt') 
const jwt = require('jsonwebtoken');
const { Timestamp } = require('mongodb');
const { response } = require('express');
const blackListedTokens = require('../models/TokenBlackList');
const ReplacementRequest = require('../models/ReplacementRequest');
const { date } = require('joi');
const location = require('../models/location');
const acJoi = require('../joiRoutesSchemes/acJoi');
const Course = require('../models/Course');
//auth
const acAuth=async (req,res,next)=>{
    try{    
        const token=req.header("token");//header in log in post request (postman)
        const isValidToken = await blackListedTokens.findOne({jwt : token})
        if(isValidToken){
            return res.status(401).json({msg:"Not signed in"});
        }
        const verified= jwt.verify(token,process.env.tokenSecret);//JWT_PASSWORD
        const member= await staffModel.findOne({"id": verified.id});
        const role=member.role;
        if(role!='HR'){
            const user = member
            req.user = user;
          //  console.log(user)
            next();
        }
        else return res.status(401).json({err:"No access rights"});
    }
    catch(err){
        return res.status(500).json({err:err.message});
    }
}

//routes start here

//view schedule and replacements
router.route('/schedule')
.get(acAuth,async(req,res)=>{//no body
    try{
        const member = req.user
       // console.log(member)// submitted uncommented
        const ID=member.id
     //   const member= await staffModel.findOne({"id": ID});
        let schedule=member.schedule;
        let requestsSender=await replacementRequest.find({senderId: ID,statusHod:"accepted"})
        let requestsReceiver=await replacementRequest.find({receiverId: ID,statusInst:"accepted",statusHod:"accepted"})
        let leaveRequest=await LeaveRequest.find({senderId:ID,status:'accepted'})
        //determining which week am in sat to thur
        let currDate=new Date()
        let today=(currDate.getDay()+1)%7
        let sat=new Date(currDate)
        sat.setDate(sat.getDate()-today)
        let thur=new Date(currDate)
        thur.setDate(thur.getDate()-today+5)

        requestsReceiver=requestsReceiver.filter((request )=> request.Date>=sat&&request.Date<=thur)
        requestsSender=requestsSender.filter((request )=> request.Date>=sat&&request.Date<=thur)

        let leaveDates=[]
        let noTeach=[]
        let replace=[]
        let slotSend=[]
        let slotRec=[]
        let replaceSender=[]
        
        let leaveDatesS=[]
        let noTeachS=[]
        let replaceS=[]

        let repRecElement=(element)=>{
            replace.push(element.Date.getDay())
            replaceSender.push(element.senderId)
            if(element.slot!=null)
                slotRec.push(element.slot)
            else
                slotRec.push('no')
        }

        let repSendElement=(element)=>{
            noTeach.push(element.Date.getDay())
            if(element.slot!=null)
                slotSend.push(element.slot)
            else
                slotSend.push('no')
        }

        requestsSender.forEach(repSendElement)
        requestsReceiver.forEach(repRecElement)
        

        for(let i=0;i<leaveRequest.length;i++){
            let sd=new Date(leaveRequest[i].startDate)
            let pol=leaveRequest[i].periodOfLeave
            for(let i=0;i<pol;i++){
                if(sd>=sat&&sd<=thur)
                    leaveDates.push(sd.getDay())
                sd.setDate(sd.getDate() + 1)
            }
        }
        for(let i=0;i<leaveDates.length;i++){
            leaveDatesS[i]=getDayy(leaveDates[i])
        }
        for(let i=0;i<noTeach.length;i++){
            noTeachS[i]=getDayy(noTeach[i])
        }
        for(let i=0;i<replace.length;i++){
            replaceS[i]=getDayy(replace[i])
        }
        for(let i=0;i<schedule.length;i++){
            if(leaveDatesS.includes(schedule[i].day)){
                schedule.splice(i,1)
                i--
            }else{
                for(let j=0;j<noTeach.length;j++){
                    if(noTeachS[j]==schedule[i].day&&(slotSend[j]=='no'||slotSend[j]==schedule[i].slot)){
                        schedule.splice(i,1)
                        i--
                        break
                    }
                }
            }
        }
        for(let i=0;i<replace.length;i++){
            let sch=(await staffModel.findOne({id:replaceSender[i]})).schedule
            for(let j=0;j<sch.length;j++){
                if(sch[j].day==replaceS[i]&&(sch[j].slot==slotRec[i]||slotRec[i]=='no'))
                    schedule.push(sch[j])
            }
        }
        for(let i=0;i<schedule.length;i++){
            let curr=schedule[i]
            let courseCode=(await Course.findOne({_id:curr.course})).code
            let loc=(await Location.findOne({_id:curr.location})).name
            schedule[i].location=loc
            schedule[i].course=courseCode
        }
        res.send(schedule)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

let getAnnualLeaves=async(ID)=>{// el month 10-1
    let currMonth=new Date().getMonth()+1
    let currDay=new Date().getDate()
    let currYear=(new Date).getFullYear()
    if(currDay<11){
        currMonth-=1
        if(currMonth==0){
            currMonth=12
            currYear-=1
        } 
    } 
    let annualDays=(currMonth-1)*2.5
    const leaves=await LeaveRequest.find({senderId:ID,status:'accepted', $or:[{typeOfLeave:'Annual'},{typeOfLeave:'Accidental'}]})
    let numL=leaves.filter(e=>e.Date>new Date(currYear+"-"+1+"-"+10)&&e.Date<new Date((currYear+1)+"-"+1+"-"+11)).length
    leaves.forEach(e=>{if(e.typeOfLeave=='Accidental')numL+=(e.periodOfLeave-1)})
    let replacement=await ReplacementRequest.find({senderId:ID,statusHod:'accepted'})
    let numR=replacement.filter(e=>e.Date>new Date(currYear+"-"+1+"-"+10)&&e.Date<new Date((currYear+1)+"-"+1+"-"+11)).length
    console.log(Math.floor(annualDays-(numL+numR) ))
    return Math.floor(annualDays-(numL+numR) )
}

router.route('/replacementRequest')
.post(acAuth,async(req,res)=>{//receiverID, date
    try{
        const member = req.user
        const senderID=member.id
        const receiverID=req.body.receiverId
        await acJoi.replacementJoi.validateAsync(req.body)
        const receiverMember=await staffModel.findOne({id:receiverID})
        if(!receiverMember)
            return res.status(400).json({err:"ID doesn't exist"});
        if((await replacementRequest.findOne({$or:[{senderId:senderID},{receiverId:receiverID}],$or:[{senderId:receiverID},{receiverId:senderID}],Date:req.body.Date,slot:req.body.slot}))) 
            return res.status(400).json({err:"replacement request for that day already exists"});
    //    const member= await staffModel.findOne({"id": senderID})
        if(getAnnualLeaves(senderID)<=0)
            return res.status(400).json({err:"you have consumed all your annual leaves"});
        req.body.Date=new Date(req.body.Date)
        let cd=req.body.Date.getDay()
        let cds=getDayy(cd)
        if(cds=='Friday')
            return res.status(400).json({err:"no leave requests on friday"})
        if((member.schedule.filter(s=>s.day==cds)).length==0)
            return res.status(400).json({err:"can't send a replacement request for a day with no teaching activities issue an annual leave request"});
        if(member.role=='HR'||receiverMember.role=='HR')
            return res.status(400).json({err:"no replacements for HR members"});
        if((member.role=='TA'||member.role=='coordinator')&&(receiverMember.role=='HOD'||receiverMember.role=='instructor'))
            return res.status(400).json({err:"you can't do replacement with HOD or instructor"});
        if((member.role=='HOD'||member.role=='instructor')&&(receiverMember.role=='TA'||receiverMember.role=='coordinator'))
            return res.status(400).json({err:"you can't do replacement with TA or coordinator"});
        const department=member.department
        if(req.body.slot!=null)
            switch(req.body.slot){
                case '1st':case '2nd':case '3rd':case '4th':case '5th':break;case '':break;
                default:return res.status(400).json({err:"slot period does not exist"})
            }
        if(department!=receiverMember.department)
            return res.status(400).json({err:"the person you want to do replacement with is not from the same department"});
        if(req.body.Date<=new Date())
            return res.status(400).json({err:"request date should be in the future (starting from tomorrow)"});
        const result=new replacementRequest({senderId:senderID,receiverId:receiverID,department:department,
        statusInst:"pending",statusHod:"notSent",SeenSender:false,SeenReceiver:false,
        reason:req.body.reason,Date:req.body.Date,slot:req.body.slot})
        await result.save()
        res.status(200).json({msg:"added successfully"})

    }catch(err){
        console.log('bye')
        return res.status(500).json({err:err.message});
    }
})
.get(acAuth,async(req,res)=>{
    try{
        const member = req.user
        const id=member.id
    //    const member=await staffModel.findOne({id:id})
        let result =[[],[]]
        const requests=await replacementRequest.find({receiverId:id})
        result[0]=requests
        await replacementRequest.updateMany({$or:[{senderId:id},{receiverId:id}]},{SeenSender:true})
        if(member.role=='HOD'){
            const dep=await Department.findOne({headOfDepartmentId:id})
            let requestHOD=await replacementRequest.find({department:dep._id,statusHod:{ $ne: 'notSent' }})
            result[1]=requestHOD
            await replacementRequest.updateMany({department:dep._id,statusHod:{ $ne: 'notSent' }},{SeenReceiver:true})
        }
        res.send(result)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})
.put(acAuth,async(req,res)=>{
    try{
        const user = req.user
        const senderID=user.id
        const receiverID=req.body.receiverId
        const receiverMember=await staffModel.findOne({id:receiverID})
        req.body.Date=new Date(req.body.Date)
        await acJoi.replacementJoi.validateAsync(req.body)
        if(!receiverMember)
            return res.status(400).json({err:"ID doesn't exist"});
        const request =await replacementRequest.findOne({senderId:senderID,receiverId:receiverID,Date:req.body.Date})
        if(!request) 
            return res.status(400).json({err:"no replacement request has been sent to that colleague"});
        const result=await replacementRequest.updateOne({ senderId:senderID,receiverId:receiverID,Date:req.body.Date},{statusHod:"pending",SeenSender:false,SeenReceiver:false})
        res.status(200).json({msg:"added successfully"})
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

router.route('/replacementRequestAccReg')//handle case en 3andy slots we ana ba accept wala la2 aw handle-ha fy post
.put(acAuth,async(req,res)=>{
    try{
        const user = req.user
        const receiverID=user.id
        const senderID=req.body.senderId
        const receiverMember=await staffModel.findOne({id:senderID})
        if(!receiverMember)
            return res.status(400).json({err:"ID doesn't exist"});
        const request =await replacementRequest.findOne({senderId:senderID,receiverId:receiverID,Date:req.body.Date})
        if(!request) 
            return res.status(400).json({err:"no replacement request has been sent from that colleague"});
        if(request.statusHod=='accepted'||request.statusHod=='rejected')
            return res.status(400).json({err:"HOD have already accepted or rejected that request"})    
        if(request.statusInst=='accepted'||request.statusInst=='rejected')
            return res.status(400).json({err:"you have already accepted or rejected that request"})
        if(req.body.statusInst!='accepted'&&req.body.statusInst!='rejected')
            return res.status(400).json({err:"you are allowed to either accept (accepted) or reject (rejected)"})
        const result=await replacementRequest.updateOne({ senderId:senderID,receiverId:receiverID,Date:req.body.Date},{statusInst:req.body.statusInst,SeenReceiver:true})
        res.status(200).json({msg:"added successfully"})
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

router.route('/slotLinkingRequest')
.post(acAuth,async(req,res)=>{
    try{

        const user = req.user
        const ID=user.id
        await acJoi.slotLinkingRequestJoi.validateAsync(req.body)
        if(await slotLinking.findOne({senderId:ID,slot:req.body.slot,day:req.body.day}))
            return res.status(400).json({err:"request already exist for the same slot and day"})
        const c=await course.findOne({code:req.body.courseCode})
        if(!c)
            return res.status(400).json({err:"course code does not exist"})
        const courseID=c.id
        switch(req.body.slot){
            case '1st':case '2nd':case '3rd':case '4th':case '5th':break;
            default:return res.status(400).json({err:"slot period does not exist"})
        }
        switch(req.body.day){
            case 'Saturday':case 'Sunday':case 'Monday':case 'Tuesday':case 'Wednesday':case 'Thursday':break;
            default:return res.status(400).json({err:"day does not exist"})
        }
        const loc=await location.findOne({name:req.body.location})
        if(!loc)
            return res.status(400).json({err:"location code does not exist"})
        if(loc.type=='office')
            return res.status(400).json({err:"location should be a room"})
        
        const result=new slotLinking({senderId:ID,courseId:courseID,
        status:'pending',slot:req.body.slot,day:req.body.day,
        SeenSender:false,SeenReceiver:false,location:loc.id})
        await result.save()
        res.status(200).json({msg:"added successfully"})
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

router.route('/changeDayOff')
.post(acAuth,async(req,res)=>{
    try{
        const member = req.user
        const Id=member.id
        await acJoi.changeDayOffJoi.validateAsync(req.body)
    //    const member= await staffModel.findOne({id: Id})
        if(await ChangeDayOff.findOne({senderId:Id,newday:req.body.newday}))
            return res.status(400).json({err:"that is your day off"})
        if(member.dayOff==req.body.newday)
            return res.status(400).json({err:"that is your day off"})
        switch(req.body.newday){
            case 'Saturday':case 'Sunday':case 'Monday':case 'Tuesday':case 'Wednesday':case 'Thursday':break;
            default:return res.status(400).json({err:"day does not exist"})
        }
        const result=new ChangeDayOff({senderId:Id,newday:req.body.newday,
        status:"pending",reasonOfChange:req.body.reasonOfChange,
        comment:req.body.comment,department:member.department,SeenSender:false,SeenReceiver:false})
        await result.save()// reason and comment may not be included in the body
        res.status(200).json({msg:"added successfully"})
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

let getDayy=(cd)=>{
    let cds
    switch(cd){
        case 0:cds='Sunday';break
        case 1:cds='Monday';break
        case 2:cds='Tuesday';break
        case 3:cds='Wednesday';break
        case 4:cds='Thursday';break
        case 5:cds='Friday';break
        case 6:cds='Saturday';break
    }
    return cds
}

router.route('/leaveRequest')
.post(acAuth,async(req,res)=>{
    try{    
        const member = req.user
        const Id=member.id
        await acJoi.leaveRequestJoi.validateAsync(req.body)
   //     const member= await staffModel.findOne({id: Id})
        req.body.startDate=new Date(req.body.startDate)
        let date =new Date(req.body.startDate)
        for(let i=0;i<req.body.periodOfLeave;i++){
            let x=await LeaveRequest.find({senderId:Id,startDate:date,status:{$ne:'rejected'}})
            if(x.length!=0)
                return res.status(400).json({err:"leave request for that day already pending or accepted"})
        date.setDate(date.getDate() + 1)
        }
        let cd=req.body.startDate.getDay()
        let cds=getDayy(cd)
        if(cds=='Friday')
            return res.status(400).json({err:"no leave requests on friday"})        
        switch(req.body.typeOfLeave){
            case 'Annual':
                if(req.body.startDate<=new Date())
                    return res.status(400).json({err:"Annual leaves should be submitted before the targeted day"})
                if(req.body.periodOfLeave!=1||(await getAnnualLeaves(Id))<0)
                    return res.status(400).json({err:"period of leave should be 1 or you have consumed your annual leaves"})
                if(member.schedule.filter(s=>s.day==cds).length==0){
                    return res.status(400).json({err:"you have teaching on that day go and issue a replacement request"})                    
                }
                break;
            case 'Accidental':
                let anl=await getAnnualLeaves(Id)
                if(req.body.periodOfLeave>6||anl<req.body.periodOfLeave)
                    return res.status(400).json({err:"period of leave should be less than 6 and cannot exceed your annual leave balance : "+anl})
                break
            case 'Sick':
                if(req.body.document==null)
                    return res.status(400).json({err:"a document has to be submitted in sick leaves"})
                date =new Date(req.body.startDate)
                date.setDate(date.getDate() -3)
                if(date>(new Date()))
                    return res.status(400).json({err:"cannot submit after the date by more than three days"})
                break
            case 'Maternity':
                if(req.body.document==null)
                    return res.status(400).json({err:"a document has to be submitted in maturnity leaves"})
                if(member.gender!='female')
                    return res.status(400).json({err:"maturnity leaves are only for female staff"})
                break
            case 'Compensation':
                if(req.body.compensatingDay==null)
                    return res.status(400).json({err:"you have to enter a compensating day"})
                req.body.compensatingDay=new Date(req.body.compensatingDay)
                cd=(req.body.compensatingDay).getDay()
                cds=getDayy(cd)
                if(member.dayOff!=cds)
                    return res.status(400).json({err:"compensations have to be on your day off"})
                let z=new Date()
                let d=z.getDate()
                let m=z.getMonth()+1
                let y=z.getFullYear()
                let pre;let post
                if(d<11){
                    post=new Date(y+"-"+m+"-"+10)
                    if(m==1){
                        m=12
                        y-=1
                    }
                    pre=new Date(y+"-"+m+"-"+11)
                }else{
                    pre=new Date(y+"-"+m+"-"+11)
                    if(m==12){
                        m=1
                        y+=1
                    }
                    post=new Date(y+"-"+m+"-"+10)
                }
                if(req.body.compensatingDay>new Date()&&req.body.startDate<new Date()&&(req.body.compensatingDay>=pre&&
                    req.body.compensatingDay<=post)&&(req.body.startDate>=pre&&req.body.startDate<=post))
                    return res.status(400).json({err:"compensating day and absent day have to be in this month"})
                const x=await viewMissing.viewMissingDays(member);
                if(x.length==0)
                    return res.status(400).json({err:"you can only compensate a day that you were absent in this month"})
                let sdd=req.body.startDate
                    if((x.filter(e=>e.getFullYear()==sdd.getFullYear()&&e.getMonth()==sdd.getMonth()&&e.getDate()&&sdd.getDate())).length==0)
                        return res.status(400).json({err:"you were not absent that day"})
                console.log(x)
                break;
            default:return res.status(400).json({err:"type of leave does not exist"})
        }
        const result =new LeaveRequest({senderId:Id,
            typeOfLeave:req.body.typeOfLeave,
            status:"pending",
            startDate:req.body.startDate,
            periodOfLeave:req.body.periodOfLeave,
            document:req.body.document,//leh el document string
            department:member.department,
            reason:req.body.reason,
            SeenSender:false,
            SeenReceiver:false,
            compensatingDay:req.body.compensatingDay})
        await result.save()
        res.status(200).json({msg:"added successfully"})
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

router.route('/notification')
.get(acAuth,async(req,res)=>{
    try{
        const user = req.user
        const id=user.id
        
        let promises = [replacementRequest.find({senderId:id,SeenSender:false,statusInst:{ $ne: 'pending' },statusHod:'notSent'}),
        replacementRequest.find({senderId:id,SeenSender:false, $or: [{statusHod: 'accepted'}, {statusHod: 'rejected'}] }),
        LeaveRequest.find({snederId:id,SeenSender:false,status:{ $ne: 'pending' }}),
        ChangeDayOff.find({senderId:id,SeenSender:false,status:{ $ne: 'pending' }}),
        slotLinking.find({senderId:id,SeenSender:false,status:{ $ne: 'pending' }})]

        let result = await Promise.allSettled(promises).then((res) => {
            let xresult={"replacementsInst":res[0].value,"replacementsHod":res[1].value
            ,"leaveReq":res[2].value,"changeDayOff":res[3].value,
            "slotInking":res[4].value}
            return xresult;
            }         
        )
        let update=[replacementRequest.updateMany({senderId:id,SeenSender:false,statusInst:{ $ne: 'pending' },statusHod:'notSent'},{SeenSender:true}),
        replacementRequest.updateMany({senderId:id,SeenSender:false,$or: [{statusHod: 'accepted'}, {statusHod: 'rejected'}]},{SeenSender:true}),
        LeaveRequest.updateMany({snederId:id,SeenSender:false,status:{ $ne: 'pending' }},{SeenSender:true}),
        ChangeDayOff.updateMany({senderId:id,SeenSender:false,status:{ $ne: 'pending' }},{SeenSender:true}),
        slotLinking.updateMany({senderId:id,SeenSender:false,status:{ $ne: 'pending' }},{SeenSender:true})]
        await Promise.allSettled(update).then()
        res.send(result)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

router.route('/viewStatusOfRequests')
.get(acAuth,async(req,res)=>{
    try{
        const user = req.user
        const id=user.id

        //replacementRequests
        const senderRecRR=await replacementRequest.find({$or:[{senderId:id},{receiverId:id}]})
        const senderRR=senderRecRR.filter(e=>e.senderId==id)
        const receiverRR=senderRecRR.filter(e=>e.receiverId==id)
        //leaveRequests
        const senderLR=await LeaveRequest.find({senderId:id})
        //changeDayOff requests
        const senderCR=await ChangeDayOff.find({senderId:id})
        //slotLinking requests
        const senderSR=await slotLinking.find({senderId:id})
         if(senderSR.length!=0){
             for(let i=0;i<senderSR.length;i++){
             const cou=await course.findOne({_id:senderSR[i].courseId})
             const loc=await Location.findOne({_id:senderSR[i].location})
             senderSR[i].courseId=cou.code
             senderSR[i].location=loc.name
             }
         }    
        let result=[senderRR,receiverRR,senderLR,senderCR,senderSR]
        await replacementRequest.updateMany({senderId:id},{SeenSender:true})
        await replacementRequest.updateMany({receiverId:id},{SeenReceiver:true})
        await LeaveRequest.updateMany({ senderId: id },{SeenSender:true})
        await ChangeDayOff.updateMany({ senderId: id },{SeenSender:true})
        await slotLinking.updateMany({ senderId: id },{SeenSender:true})

        res.send(result)
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})


router.route('/cancelRequest')
.delete(acAuth,async(req,res)=>{
    try{
        const user = req.user
        const id=user.id
        let result
        switch(req.body.typeOfRequest){
            case 'replacementRequests':
                result=await replacementRequest.findOne({_id:req.body.reqId,senderId:id})
                if(result!=null&&(result.Date>new Date()||result.statusInst=='pending')){
                    await replacementRequest.deleteOne({_id:req.body.reqId,senderId:id})
                }else if(result!=null&&(result.Date>new Date()||result.statusHod=='pending')){
                    await replacementRequest.deleteOne({_id:req.body.reqId,senderId:id})
                }else
                    return res.status(400).json({err:"this request is not found or the request is not pending or its date has already come"})
                break
            case 'leaveRequests':
                result=await LeaveRequest.findOne({_id:req.body.reqId,senderId:id})
                if(result!=null&&(result.startDate>new Date()||result=='pending'))
                    await LeaveRequest.DeleteOne({_id:req.body.reqId,senderId:id})
                else
                    return res.status(400).json({err:"this request is not found or the request is not pending or its date has already come"})
                break            
            case 'changeDayOffRequests'://mafish start date
                result=await ChangeDayOff.findOneAndDelete({_id:req.body.reqId,senderId:id,status:"pending"})
                break
            case 'slotLinkingRequests'://mafish start date
                result=await slotLinking.findOneAndDelete({_id:req.body.reqId,senderId:id,status:"pending"})
                break
            default:return res.status(400).json({err:"enter correct type of request"})
        }
        if(!result)
            return res.status(400).json({err:"enter correct type name"})
        res.status(200).json({msg:"canceled successfully"})
    }catch(err){
        return res.status(500).json({err:err.message});
    }
})

module.exports= router