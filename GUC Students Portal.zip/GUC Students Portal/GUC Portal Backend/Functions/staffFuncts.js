const staffModel= require('../models/staff');
const leaveReqModel = require('../models/LeaveRequest');


async function viewMissingDays(user) {
    const signInLogs = user.signInLogs;
    const currDate = new Date();
    let signInLogsYear = currDate.getFullYear();
    signInLogs.sort(function(a,b){
        return new Date(a.timeStamp) - new Date(b.timeStamp);
    });
    let lastMonth = currDate.getDate() < 11 ? currDate.getMonth() : currDate.getMonth() + 1
    //console.log(lastMonth)
    if(lastMonth == 0 && currDate.getDate() < 11) {lastMonth = 12; signInLogsYear -= 1;}                                               
    
    const fromMonthDate = new Date(Date.UTC(signInLogsYear,lastMonth-1, 11 , 0,0,0,0))    // from month   //check this again

    let numberOfDaysInMonth = new Date(signInLogsYear,lastMonth,0).getDate()  // get no. of days in a month  //check this again

    const toMonthDate =new Date()  
    toMonthDate.setUTCDate(toMonthDate.getDate()-1)
    toMonthDate.setUTCHours(21);
    //console.log(fromMonthDate)
    //console.log(toMonthDate)// to month

    let logsOfMonthDays = signInLogs.filter(                                     //array of logs between day 11 in month x and day 10 in month after x
        log => log.timeStamp >= fromMonthDate && log.timeStamp <= toMonthDate
    )  

    logsOfMonthDays.sort(function(a,b){
        return new Date(a.timeStamp) - new Date(b.timeStamp);
    });
    //console.log(logsOfMonthDays)
    let notAttendedDays = [];       // array of not attended days in the month
     
    let i = 11;
    let changedCounter = false;
    let j = 0;

    let day=fromMonthDate;
    toMonthDate.setHours(10)
    let enteredloop = false;
    for(; i <= numberOfDaysInMonth&&day<toMonthDate ; i++){        // for loop for the previous month from day 11 till the end of the month
        let isAttended = false;                                          
        for(j ; j < logsOfMonthDays.length ; j++){
            if(logsOfMonthDays[j].timeStamp.getDate() == i){
                let signInType = logsOfMonthDays[j].type;
                if(signInType == "out")
                {
                    isAttended = false;
                    continue;
                } 
                else{
                    while(  j < logsOfMonthDays.length && logsOfMonthDays[j].timeStamp.getDate() == i){
                        if(logsOfMonthDays[j].type == "out"){
                            isAttended = true;
                        }
                        if(!enteredloop && j == logsOfMonthDays.length -1) {
                            enteredloop = true;
                        }
                        j++;
                    }
                    
                }
                if(!isAttended) {
                    let month = numberOfDaysInMonth != 10 ? fromMonthDate.getMonth() : toMonthDate.getMonth();
                    let year  = numberOfDaysInMonth != 10 ? fromMonthDate.getFullYear() : toMonthDate.getFullYear();
                    day = new Date(year,month,i,12,0,0,0);
                    notAttendedDays.push(day);
                }
                break;
            }
            else{
                if(notAttendedDays.length == 0 || notAttendedDays[notAttendedDays.length-1].getDate() != i){                    
                    let month = numberOfDaysInMonth != 10 ? fromMonthDate.getMonth() : toMonthDate.getMonth();
                    let year  = numberOfDaysInMonth != 10 ? fromMonthDate.getFullYear() : toMonthDate.getFullYear();
                    day = new Date(year,month,i,12,0,0,0);
                    notAttendedDays.push(day);
                }
                break;
            }
        }
        if(logsOfMonthDays.length==0||(j==logsOfMonthDays.length && !enteredloop)) {  // added !enteredloop
            let month = numberOfDaysInMonth != 10 ? fromMonthDate.getMonth() : toMonthDate.getMonth();
            let year  = numberOfDaysInMonth != 10 ? fromMonthDate.getFullYear() : toMonthDate.getFullYear();
            day = new Date(year,month,i,12,0,0,0);
            notAttendedDays.push(day);
        }
        if(i == numberOfDaysInMonth && !changedCounter){
            i = 0;
            numberOfDaysInMonth = 10;
            changedCounter = true;
        }
       
    }
    var days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayOff = days.indexOf(user.dayOff.toLowerCase());
    const friday = 5;
    const arrOff = [friday,dayOff]
    const userId = user.id;

    let leaveRequests;
    try {
        leaveRequests = await leaveReqModel.find({"senderId" : userId});    }
    catch(err){
        console.log("error in finding leave req")
    }
    for(i = 0 ; i < notAttendedDays.length ; i++){
        
        const dd = notAttendedDays[i].getDay();
        const d = notAttendedDays[i].getDate();
        const m = notAttendedDays[i].getMonth()+1;
        const y = notAttendedDays[i].getFullYear();
        if(arrOff.indexOf(dd) != -1){
            notAttendedDays.splice(i,1);
            i--;
        }
        else{
            if(!leaveRequests){
                continue;
            }
            
            let reqOfNotAttendedDay = leaveRequests.filter(                                     //array of logs between day 11 in month x and day 10 in month after x
                req => req.startDate.getFullYear() == y && req.startDate.getMonth()+1 == m 
                && req.startDate.getDate() == d && req.status == "accepted"
            ) 
            if(reqOfNotAttendedDay.length != 0){

                const request = reqOfNotAttendedDay[reqOfNotAttendedDay.length-1]
                let startDay = request.startDate;
                const periodOfLeave = request.periodOfLeave
                for(k = 0 ; k < periodOfLeave ; k++){
                    for(h = 0 ; h < notAttendedDays.length ; h++){
                        if(notAttendedDays[h].getMonth() == startDay.getMonth() &&
                        notAttendedDays[h].getFullYear() == startDay.getFullYear() &&  notAttendedDays[h].getDate() == startDay.getDate()){
                            notAttendedDays.splice(h,1);
                            break;
                        }
                    } 
                    startDay.setDate(startDay.getDate() + 1);
                }    
            }
        }
       
    }
    return notAttendedDays;
}

async function viewMissingHours(user){
    const signInLogs = user.signInLogs;
    const currDate = new Date();
    currDate.setUTCDate(currDate.getDate()-1)
    currDate.setUTCHours(20);
    let signInLogsYear = currDate.getFullYear();

    signInLogs.sort(function(a,b){
        return new Date(a.timeStamp) - new Date(b.timeStamp);
    });

    let lastMonth = currDate.getDate() < 11 ? currDate.getMonth() : currDate.getMonth()+1
    if(lastMonth == 0 && currDate.getDate() < 11) {lastMonth = 12; signInLogsYear -= 1;} //added && currDate.getDate() < 11 as in missingDays                                           
    const fromMonthDate = new Date(Date.UTC(signInLogsYear,lastMonth-1, 11 , 0,0,0,0))
    const toCurrDate = currDate;
    let logsOfMonthDays = signInLogs.filter(                                     //array of logs between day 11 in month x and day 10 in month after x
        log => log.timeStamp >= fromMonthDate && log.timeStamp <= toCurrDate
    )
    logsOfMonthDays.sort(function(a,b){
        return new Date(a.timeStamp) - new Date(b.timeStamp);
    });

    let missingHours = 0;
    let extraHours = 0;
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayOff = days.indexOf(user.dayOff.toLowerCase());
    const friday = 5;
    const arrOff = [friday,dayOff]

    for (i = 0 ; i < logsOfMonthDays.length ; i++ ){
        let currDayInLog = logsOfMonthDays[i].timeStamp.getDate();
        let currDayLogs = [];
        while(i < logsOfMonthDays.length && logsOfMonthDays[i].timeStamp.getDate() == currDayInLog){
            currDayLogs.push(logsOfMonthDays[i])
            i++;
        }
        i--;
        for(j = 1 ; j < currDayLogs.length-1 ; j++){
            if(currDayLogs[j].type == "out" && currDayLogs[j-1].type == "in"){
                let missingSeconds = Math.abs(currDayLogs[j-1].timeStamp.getSeconds()/60 - currDayLogs[j].timeStamp.getSeconds()/60);
                let missingMinutes = Math.abs(currDayLogs[j-1].timeStamp.getMinutes() - currDayLogs[j].timeStamp.getMinutes());
                let currMissingHours = Math.abs(currDayLogs[j-1].timeStamp.getHours()*60 - currDayLogs[j].timeStamp.getHours()*60);
                let total = Math.abs((currMissingHours+missingMinutes));
                const dd = currDayLogs[j].timeStamp.getDay();
                if(arrOff.indexOf(dd) != -1){
                   extraHours+=total;
                }
                else{
                    if ((504 - total) < 0){
                        extraHours += (total - 504);
                    }
                    else{
                        missingHours += (504 - total)
                    } 
                }       
            }
        }
        if(currDayLogs.length >= 2 && currDayLogs[currDayLogs.length-1].type == "out" && currDayLogs[currDayLogs.length-2].type == "in"){
            let missingMinutes = Math.abs(currDayLogs[currDayLogs.length-1].timeStamp.getMinutes() - currDayLogs[currDayLogs.length-2].timeStamp.getMinutes());
            let currMissingHours = Math.abs(currDayLogs[currDayLogs.length-1].timeStamp.getHours()*60 - currDayLogs[currDayLogs.length-2].timeStamp.getHours()*60);
            let total = Math.abs((currMissingHours+missingMinutes));
            const dd = currDayLogs[currDayLogs.length-1].timeStamp.getDay();
            if(arrOff.indexOf(dd) != -1){
                extraHours+=total;
            }
            else{
                if ((504 - total) < 0){
                    extraHours += (total - 504);
                }
                else{
                    missingHours += (504 - total)
                }  
            }   
        }
    }
    return {
        missingHours : parseFloat((missingHours/60).toFixed(3)),
        extraHours : parseFloat((extraHours/60).toFixed(3))
    }
}


module.exports = {
    viewMissingDays : viewMissingDays,
    viewMissingHours : viewMissingHours
} 