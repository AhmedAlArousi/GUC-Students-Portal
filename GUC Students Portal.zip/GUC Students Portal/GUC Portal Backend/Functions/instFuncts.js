const depModel = require('../models/Department');
const locationModel = require('../models/location');

async function getDepartmentName(dep){
    if (dep=="N/A"){
        return dep;
    }
    else{
        const ddoc = await depModel.findOne({_id:dep});
        return ddoc.name +'('+ddoc.code+')';
    }
}

function getRoleExtended(role){
    switch (role){
        case "HOD": return "Head Of Department (HOD) & Instructor";
        case "instructor": return "Instructor";
        case "TA": return "Teaching Assistant (TA)";
        case "coordinator": return "Course Coordinator & Teaching Assistant";
        default : return role;

    }
}

async function getLocationName(office){
    console.log("of:",office);
    if (office=="N/A"){
        return office;
    }
    else{
        const odoc = await locationModel.findOne({_id:office});
        // console.log("odoc",odoc);
        return odoc.name;
    }
}

async function viewProfile(userDoc){
    const dep = await getDepartmentName(userDoc.department);
    const role = getRoleExtended(userDoc.role);
    const office = await getLocationName(userDoc.officeLocation);
    // console.log("finOffice",office);
    const res =  {"ID":userDoc.id,
        "Name":userDoc.name,
        "Email":userDoc.email,
        "Office Location":office,
        "Gender":userDoc.gender,
        "Role": role,
        "Dayoff":userDoc.dayOff,
        "Department": dep
    };
    // console.log(res);
    return res;
};

// async function getSlotLoc(body){
//     var slotLoc = ''; 
//     if (req.body.hasOwnProperty("location")){
//         //either given a valid-format location or given 'N/A' to match with it
//         slotLoc = body.location;
//         if(!slotLoc=='N/A'){
//             const slotLocDoc = await locationModel.findOne({name:slotLoc});
//             if (!slotLocDoc){//check existence of input location
//                 //slotLoc = 'N/A';
//                 return res.status(406).send("The location entered doesn't exist");
//             }
//             else{
//                 slotLoc = slotLocDoc._id;
//             }
//         }
//     }
// };

module.exports = {
    viewProfile: viewProfile

}